function CORR(directions)
% This function can caculate the corr of different sites in one direction
% The length of the time series should be consistent
    if nargin ~= 1
        error('error input arguments!')
    end
    switch directions
        case 'one direction'
            step = 1;
        case 'three directions'
            step = 3;
        otherwise
            error('error choice!')
    end
    filepath = uigetdir(strcat(cd,'\example\NoiseReduction'),'Please choose a folder'); 
    current = filepath;
    A = dir(current);
    if step == 1
        for ss = 3:step:length(A)
            folder = strcat(current,'\',A(ss,1).name);
            fid = fopen(folder);
            data =  textscan(fid,' %f%f','headerlines',1);
            E(:,ss-2) = data{2};
            fclose(fid);
        end
        [m,n]=size(E);
        % caculate corr
        for i=1:n
            for j=1:n
                rx=corr([E(:,i),E(:,j)]);
                ree(i,j)=rx(1,2);
            end
        end
        %  ree' 
        dname = [cd '\TSexpression\Corr'];
        fn = '\\Corr.txt';
        save ([dname fn],'ree','-ascii')
        open([dname fn])
    end
    
    if step == 3
        for ss = 3:step:length(A)
            folder = strcat(current,'\',A(ss,1).name);
            fid = fopen(folder);
            data =  textscan(fid,' %f%f','headerlines',1);
            E(:,ss/3) = data{2};
            fclose(fid);
            
            folder =strcat(current,'\',A(ss+1,1).name);
            fid = fopen(folder);
            data = textscan(fid, '%f%f','headerlines',1);
            N(:,ss/3) = data{2};
            fclose(fid);
            
            folder=strcat(current,'\',A(ss+2,1).name);
            fid = fopen(folder);
            data = textscan(fid, '%f%f','headerlines',1);
            U(:,ss/3) = data{2};
            fclose(fid);
        end
        [m,n]=size(E);
        % caculate cor
        for i=1:n
            for j=1:n
                rx=corr([E(:,i),E(:,j)]);
                ree(i,j)=rx(1,2);
                ry=corr([N(:,i),N(:,j)]);
                rnn(i,j)=ry(1,2);
                rz=corr([U(:,i),U(:,j)]);
                ruu(i,j)=rz(1,2);
            end
        end
        %     ree' rnn' ruu'
        dname = [cd '\TSexpression\Corr'];
        fn = '\\CorEE.txt';
        save ([dname fn],'ree','-ascii')
        open([dname fn])
        
        fn = '\\CorNN.txt';
        save ([dname fn],'rnn','-ascii')
        open([dname fn])
        
        fn = '\\CorUU.txt';
        save ([dname fn],'ruu','-ascii')
        open([dname fn])
    end
    
    
    
    
end