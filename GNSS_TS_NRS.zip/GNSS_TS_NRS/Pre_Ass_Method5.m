function Pre_Ass = Pre_Ass_Method5(RawData,data,RealData)
%   nargin == 2 means there is't Simulated_Data
    GlobalConstant
    if nargin == 2
        if Choose_Index == 1
             corr = relative(RawData,data);
             rmse = RMSE(RawData,data);
             snr = SNR(RawData,data);
             Pre_Ass = [corr rmse snr];
        end
        if Choose_Index == 3
            for i =1: 3
                corr(i) = relative(RawData(:,i),data(:,i));
                rmse(i) = RMSE(RawData(:,i),data(:,i));
                snr(i) = SNR(RawData(:,i),data(:,i));
                Pre_Ass = [corr' rmse' snr'];
            end
        end
    end


    if nargin == 3
            corr(1) = relative(Simulated_Data,data);
            rmse(1) = RMSE(Simulated_Data,data);
            snr(1) = SNR(Simulated_Data,data);

            corr(2) = relative(RawData,data);
            rmse(2) = RMSE(RawData,data);
            snr(2) = SNR(RawData,data);
            Pre_Ass = [corr' rmse' snr'];
    end

    dname = cd;
    dname = [dname '\NoiseReduction'];
    fn = '\Pre_Ass.txt';
    fid = fopen( [dname fn] , 'a+');
    fprintf(fid,'\t***** Method5 EEMD *****\n');
    fprintf(fid,'\tCorr\tRMSE\tSNR\n');
    fclose(fid);
    save ([dname fn],'Pre_Ass','-ascii','-append')  
end