function R = R(IMF,RawData)
%   compute R/smoothness

[m n] = size(IMF);
if m==1
    IMF = IMF';
end
numerator = 0;
denominator = 0;
for i = 1:length(IMF)-1
numerator = numerator+(IMF(i+1)-IMF(i))^2;
denominator = denominator+(RawData(i+1)-RawData(i));
end

R = numerator/denominator;

end