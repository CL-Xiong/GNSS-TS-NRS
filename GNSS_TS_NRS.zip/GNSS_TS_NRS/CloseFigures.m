function CloseFigures
    number = get(gcf,'Number');
    for i = 1:number
         close(figure(i));
    end
end