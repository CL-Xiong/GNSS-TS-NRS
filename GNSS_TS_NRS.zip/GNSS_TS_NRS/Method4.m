function data = Method4(RawData)
%   Method4
%   This Method aims to replace coefficient of association
%   Determining Boundary IMF
%   save T(which is index) ,RawData and data to the file "Method4"
%   k is the position of boundary IMF

    GlobalConstant
    data = zeros(size(RawData));
for index = 1:Choose_Index
     allmode = eemd( RawData(:,index),0,1);
    [coll row] = size(allmode);
    for mmm = 1:row-1
        imf{mmm} = allmode(:,mmm+1)';
    end
    for i = 1:1:length(imf)
        Rmse(i) = RMSE(imf{i},RawData(:,index));
    end

    for i = 1:1:length(imf)
        r(i) = R( imf{i},RawData(:,index) );
    end

    PRmse = Rmse / sum(Rmse);
    Pr = r / sum(r);

    CV_PRmse = std(PRmse)/mean(PRmse);
    CV_Pr = std(Pr)/mean(Pr);
    W_PRmse= CV_PRmse / (CV_PRmse+CV_Pr);
    W_Pr = CV_Pr/(CV_PRmse+CV_Pr);
    T{index} = W_PRmse*PRmse + W_Pr*Pr;

	TT = T{index};
	
    for i = 2:length(PRmse)
    Rk_1(index,i-1) = abs ( TT(1,i-1)/TT(1,i) );
    end

    for i=1:length(Rk_1)
        if Rk_1(index,i) >= 1 && Rk_1(index,i)<=3
            break;
        end
    end

    k = i;

    for i=k+1:length(imf)
        data(:,index) = data(:,index)+(imf{i})';
    end
end

 %%  save data
 %  T, RawData and data 
    dname = [cd '\NoiseReduction\Method4'];
    fn = '\T.txt';   
    if Choose_Index == 3
        TT = [T{1}', T{2}', T{3}'];
    end
    save ([dname fn],'TT','-ascii')
    
    for i = 1:Choose_Index
        dname = [cd '\NoiseReduction\Method4'];
        if Simulated_Index == 1
            newfn{i} = 'Simulated.mom';
        end
        fn = newfn{i};
        fid = fopen([dname '\' fn],'w+');
        fprintf(fid,'# sampling period 1.0\n');
        for j = 1:length(MJD_Time)
             fprintf(fid,'%f\t',MJD_Time(j,i));
             fprintf(fid,'%f\n',data(j,i));
        end
        fclose(fid);
    end
    
    dname = cd;
    dname = [dname '\NoiseReduction\Method4'];
    fn = '\Rk_1.txt';
    save ([dname fn],'Rk_1','-ascii')

    dname = cd;
    dname = [dname '\NoiseReduction\Method4'];
    fn = '\k.txt';
    save ([dname fn],'k','-ascii')

end

