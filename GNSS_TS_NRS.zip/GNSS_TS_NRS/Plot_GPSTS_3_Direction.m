function Plot_GPSTS_3_Direction
filepath = uigetdir(strcat(cd,'\example\NoiseReduction'),'Please choose a folder'); 
current = filepath;
A=dir(current);

    for k=3:3:length(A)
        folderE=strcat(current,'\',A(k,1).name);
        folderN=strcat(current,'\',A(k+1,1).name);
        folderU=strcat(current,'\',A(k+2,1).name);

        fid1 = fopen(folderE);
        fid2 = fopen(folderN);
        fid3 = fopen(folderU);
        data=textscan(fid1,'%f %f','headerlines',1);
        timeE = data{1};
        E = data{2};

        data=textscan(fid2,'%f %f','headerlines',1);
        timeN = data{1};
        N = data{2};

        data=textscan(fid3,'%f %f','headerlines',1);
        timeU = data{1};
        U = data{2};

        fclose(fid1);
        fclose(fid2);
        fclose(fid3);

        timeE = (timeE-51544)/365.25+2000;
        timeN = (timeN-51544)/365.25+2000;
        timeU = (timeU-51544)/365.25+2000;

        figure
        subplot(3,1,1)
        plot(timeE,E,'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        pointname = A(k,1).name;
        pointname(end-5:end) = [];
        title(pointname)
        legend('East','Location','best');
        ylabel('Displacement/mm');
        xlim([timeE(1),timeE(end)])
        hold off
        
        subplot(3,1,2)
        plot(timeN,N,'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('North','Location','best');
        ylabel('Displacement/mm');
        xlim([timeN(1),timeN(end)])
        hold off

        subplot(3,1,3)
        plot(timeU,U,'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('Up','Location','best');
        ylabel('Displacement/mm');
        xlim([timeU(1),timeU(end)])
        hold off

        pointname=A(k,1).name;
        graph=strcat(cd,'\TSexpression\Plot-TS\',pointname);
        graph(end-5:end) = [];
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
    end


end