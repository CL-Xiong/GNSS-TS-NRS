

function Load_Data(Choose_Index)
GlobalConstant
cd ( [cd '\example']);
if Choose_Index == 3
    for i = 1:3
        if i==1
            [fn, path, filterindex] = uigetfile('*.mom','Select the obervation file of E direction', '*.mom');
            newfn{1} = fn;
        end
        if i==2
            [fn, path, filterindex] = uigetfile('*.mom','Select the obervation file of N direction','*.mom' );
            newfn{2} = fn;
        end
        if i==3
            [fn, path, filterindex] = uigetfile('*.mom','Select the obervation file of U direction','*.mom' );
            newfn{3} = fn;
        end
        
        if fn~=0
            filename = strcat(path,fn);
            fid1 = fopen(filename);
            data = textscan(fid1,' %f %f','HeaderLines',1);
    %         data = textscan(fid1,' %f %f');
            MJD_Time(:,i) = data{1};
            RawData(:,i) = data{2};
            fclose(fid1);
        end
    end
end
%%
if Choose_Index ==1
    [fn, path, filterindex] = uigetfile('*.mom', 'Select an obervation file','*.mom');
    if fn~=0
        newfn{1} = fn;
        filename = strcat(path,fn);
        fid1 = fopen(filename);
        data = textscan(fid1,' %f %f','HeaderLines',1);
%         data = textscan(fid1,' %f %f');
        MJD_Time = data{1};
        RawData = data{2};
        fclose(fid1);
    end
end
    a = cd;
    a(end-7:end) = [];
    cd (a);
end