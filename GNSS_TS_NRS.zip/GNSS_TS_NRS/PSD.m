function PSD(Hold)

    fs = 365.25;  % sampling rate  
    if nargin ~= 1
%         Hold = 'hold off'
        error('error input argument!');
    end
    switch Hold
        case 'hold on'
            Index = [];
        case  'hold off'
            Index = 1;
        case 'three directions'
            Index = 3;
    end  
    legendPn = [];
    filepath = uigetdir(strcat(cd,'\example\NoiseReduction'),'Please choose a folder'); 
    current = filepath;
    A = dir(current);
%% Fist choice : hold on;
    
    if strcmp(Hold,'hold on')
        figure
        for k = 3:1:length(A)
            folderE = strcat(current,'\',A(k,1).name);
            fid1 = fopen(folderE);
            data = textscan(fid1,'%f %f','HeaderLines',1);
            resi = data{2};
            fclose(fid1);

            [m,n] = size(resi);
            M = min(m,n);
            N = max(m,n);

            for i = 1:M
                s = fft(resi(:,i),N-1);
                X0 = abs(s);
                F = (0:N-2)*fs/(N-1);  % To calculate the frequency of the sampling point
                s0(2:N-1) = X0(2:end)/(0.5*(N-1));
                s0(1) = X0(1)/(N-1);
                fshift = round(0.5*(N-1));
    %             subplot(n,1,i);
                Color(k-2,:) = [rand(1,1) rand(1,1) rand(1,1)];
                if find(Color(k-2) == Color)
                    Color(k-2,:) = [rand(1,1) rand(1,1) rand(1,1)];
                end
                plot(F(1:fshift),s0(1:fshift),'color',Color(k-2,:));  % To extract half of frequency spectral because of symmetry
                Pn = A(k,1).name;
                Pn(end-3:end) = [];
                legendPn = [legendPn;Pn];
                hold on
                set(gca, 'FontName', 'Times New Roman','Fontsize',10); 
                xlim([0.1 240]);

                set(gca,'xscale','log')
                set(gca,'yscale','log')
                if (i < M)
                    set(gca,'Xticklabel',[]);
                end
                if (i == (1+M)/2)
                    ylabel('PSD(mm^2/Hz)');
                end
                if (i == M)
                    xlabel('frequency/cpy');
                end
            end
        end
        legend(legendPn,'Location','SouthEastOutside')
        graph = strcat(cd,'\TSexpression\PSD\all');
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
    end
%% Second choice : one direction
    if Index == 1
        for k = 3:1:length(A)
            folderE = strcat(current,'\',A(k,1).name);
            fid1 = fopen(folderE);
            data = textscan(fid1,'%f %f','HeaderLines',1);
            resi = data{2};
            fclose(fid1);

            [m,n] = size(resi);
            M = min(m,n);
            N = max(m,n);
            figure;
            for i = 1:M
                s = fft(resi(:,i),N-1);
                X0 = abs(s);
                F = (0:N-2)*fs/(N-1);  % To calculate the frequency of the sampling point
                s0(2:N-1) = X0(2:end)/(0.5*(N-1));
                s0(1) = X0(1)/(N-1);
                fshift = round(0.5*(N-1));
                subplot(n,1,i);
                plot(F(1:fshift),s0(1:fshift),'k');  % To extract half of frequency spectral because of symmetry
                set(gca, 'FontName', 'Times New Roman'); 
                tit = A(k,1).name;
                tit(end-3:end) = [];
                title(tit)
                xlim([0.1 240]);

                set(gca,'xscale','log')
                set(gca,'yscale','log')
                if (i < M)
                    set(gca,'Xticklabel',[]);
                end
                if (i == (1+M)/2)
                    ylabel('PSD(mm^2/Hz)');
                end
                if (i == M)
                    xlabel('frequency/cpy');
                end
            end
            pointname = A(k,1).name;
            graph=strcat(cd,'\TSexpression\PSD','\',pointname);
            graph(end-3:end) = [];
            graph = strcat(graph,'.fig');
            saveas(gcf,graph)
        end
    end
%% Third choice : three direction
    if Index == 3
        for k = 3:3:length(A)
            folderE = strcat(current,'\',A(k,1).name);
            fid1 = fopen(folderE);
            data = textscan(fid1,'%f %f','HeaderLines',1);
            E = data{2};
            fclose(fid1);

            folderN = strcat(current,'\',A(k+1,1).name);
            fid1 = fopen(folderN);
            data = textscan(fid1,'%f %f','HeaderLines',1);
            N = data{2};
            fclose(fid1);

            folderU = strcat(current,'\',A(k+2,1).name);
            fid1 = fopen(folderU);
            data = textscan(fid1,'%f %f','HeaderLines',1);
            U = data{2};
            fclose(fid1);

            resi = [E N U];
            [m,n] = size(resi);
            M = min(m,n);
            N = max(m,n);
            figure;
            for i = 1:M
                s = fft(resi(:,i),N-1);
                X0 = abs(s);
                F = (0:N-2)*fs/(N-1);  % To calculate the frequency of the sampling point
                s0(2:N-1) = X0(2:end)/(0.5*(N-1));
                s0(1) = X0(1)/(N-1);
                fshift = round(0.5*(N-1));
                subplot(n,1,i);
                plot(F(1:fshift),s0(1:fshift),'k');  % To extract half of frequency spectral because of symmetry
                set(gca, 'FontName', 'Times New Roman');
                xlim([0.1 240]);
                
                if (i == 1)
                    legend('East');
                    tit = A(k,1).name;
                    tit(end-5:end) = [];
                    title(tit)
                elseif(i == 2)
                    legend('North');
                else
                    legend('Up');
                end
                set(gca,'xscale','log')
                set(gca,'yscale','log')
                if (i < M)
                    set(gca,'Xticklabel',[]);
                end
                if (i == (1+M)/2)
                    ylabel('PSD(mm^2/Hz)');
                end
                if (i == M)
                    xlabel('frequency/cpy');
                end
            end
            pointname = A(k,1).name;
            graph = strcat(cd,'\TSexpression\PSD','\',pointname);
            graph(end-5:end) = [];
            graph = strcat(graph,'.fig');
            saveas(gcf,graph)
        end
    end
end
    
