function percentage = CME_ViewRms(filepa,method,namelist)
 path_rms0 = [cd '\CME\RMS.txt'];
 percentage = [];
 rms0 = load(path_rms0);
for i = 1:length(method)
    figure
    switch method(i)
        case 1
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Stacking Filtering')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Stacking Filtering';
              SaveFig(str)
        case 2
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Weightd Stacking')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Weightd Stacking';
              SaveFig(str)
        case 3
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Correlation Weightd Stacking')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Correlation Weightd Stacking';
              SaveFig(str)
        case 4
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Distance Weightd Stacking')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Distance Weightd Stacking';
              SaveFig(str)
        case 5
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('PCA')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-PCA';
              SaveFig(str)
    end
end
function SaveFig(str)
    dname = [cd '\CME\'];
    f = [str '.fig'];
    saveas(gcf,[dname f])
end
end