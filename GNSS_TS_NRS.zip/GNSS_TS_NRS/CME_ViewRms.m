function percentage = CME_ViewRms(filepa,method,namelist)
% percentage = (beforeRMS-afterRMS)/beforeRMS
% filepa{i} means the i-th RMS from where, which is correspond to method(i)
% namelist means the site name list
 path_rms0 = [cd '\CME\RMS.txt'];
 percentage = [];
 rms0 = load(path_rms0);
 
for i = 1:length(method)
    figure
    switch method(i)
        case 1
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Stacking Filtering')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Stacking Filtering';
              SaveFig(str)
        case 2
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Weightd Stacking')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Weightd Stacking';
              SaveFig(str)
        case 3
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Correlation Weightd Stacking')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Correlation Weightd Stacking';
              SaveFig(str)
        case 4
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('Distance Weightd Stacking')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-Distance Weightd Stacking';
              SaveFig(str)
        case 5
              rms1  = load(filepa{i});
              for j = 1:3
                  subplot(3,1,j)
                  rms_after_before = [rms0(:,j) rms1(:,j)];
                  percent = ( rms0(:,j) - rms1(:,j) )./rms0(:,j);
                  percentage = [percentage percent];
                  bar(rms_after_before)
                  set(gca,'FontName','Times new roman','Fontsize',10)
                  legend({'before','after'})
                  if j == 1
                      title('PCA')
                      set(gca,'XTickLabel','')
                  end
                  if j == 2
                      ylabel('RMS/mm');
                      set(gca,'XTickLabel','')
                  end
                  if j == 3
                      set(gca,'XTickLabel',namelist)
                  end
              end
              str = 'RMS-PCA';
              SaveFig(str)
        otherwise
            error('error method choice!')
    end
end
%% save the percentage
str = [cd '\CME\' 'percentage of RMS change.txt']
save(str,'percentage')

%%
% added on 0922
% show all RMS in three direction in three fig
for i=1:3
    figure
    plot(rms0(:,i),'-ko','linewidth',1,'markersize',6)% 1��j
    set(gca,'FontName','Times new roman','Fontsize',10)
    ylabel('RMS/mm');
    xlabel('Site');
    set(gca,'XTickLabel',namelist)
    leg{1} = 'RawData';
    hold on 
    for j = 1:length(method)
        if method(j) == 1 % method(j)
            rms1  = load(filepa{j});
            plot(rms1(:,i),'-m+','linewidth',1,'markersize',6)
            leg{j+1} = 'Stacking filtering';
        elseif method(j) == 2
            rms2  = load(filepa{j});
            plot(rms2(:,i),'-c*','linewidth',1,'markersize',6)
            leg{j+1} = 'Weighted stacking filtering';
        elseif method(j) == 3
            rms3  = load(filepa{j});
            plot(rms3(:,i),'-bx','linewidth',1,'markersize',6)
            leg{j+1} = 'Correlation weighted stacking filtering';
        elseif method(j) == 4
            rms4  = load(filepa{j});
            plot(rms4(:,i),'-rs','linewidth',1,'markersize',6)
            leg{j+1} = 'Distance weighted filtering';
        elseif method(j) == 5
            rms5  = load(filepa{j});
            plot(rms5(:,i),'-gv','linewidth',1,'markersize',6) 
            leg{j+1} = 'PCA';
        end
    end
    legend(leg)
    if i == 1
        str = 'E-Filtering';
        title('East')
    elseif i == 2
        str = 'N-Filtering';
        title('North')
    else
        str = 'U-Filtering';
        title('Up')
    end
    SaveFig(str)
end

%%
function SaveFig(str)
    dname = [cd '\CME\'];
    f = [str '.fig'];
    saveas(gcf,[dname f])
end
end