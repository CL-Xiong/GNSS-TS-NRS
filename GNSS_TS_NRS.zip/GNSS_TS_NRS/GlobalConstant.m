% RawData : the measured data or Simulated_Data
% y1 y2 y3 Noise: the element of periodic function
% Simulated_Index=1 :these is Simulated data
% Choose_Index=1 :one direction,Choose_Index=3,NEU direction
% newfn :filename
% the outset and outcome year of signal
global  RawData  Simulated_Data RealData 
global  Simulated_Index Noise_Index Simulated_Choice Choose_Index
global y1 y2 y3 Noise Data_Length
global  newfn
global MJD_Time RawMJD
global outset outcome