function Offset
    %  input:
    %             Offset Choices
    %             Amplitude
    %             OffsetNumber
    %             OffsetTime
    %  output:
    % The choices of TS want to be offseted,such as 3mm,6mm,9mm,is three choices
    clc
    clear
    prompt = {'Offset Amplitude Choices'};
    title = 'Offset Amplitude Choices';
    dims = [1 50];
    definput = {'3'};
    answer = inputdlg(prompt,title,dims,definput);
    Amplitude_Choices = str2double(answer{1}); 
    % Amplitude Choices
    for i = 1:Amplitude_Choices
        pro{i} = strcat('Amplitude ',num2str(i),'(mm)');
    end
    prompt = pro;
    title = 'Offset Amplitude Choices';
    dims = [1 50];
    answer = inputdlg(prompt,title,dims);
    for i = 1:Amplitude_Choices
        Amplitude(i) = str2double(answer{i});
    end
    %  Offset Choices
    prompt = {'Offset Choices'};
    title = 'Offset Choices';
    dims = [1 50];
    definput = {'3'};
    answer = inputdlg(prompt,title,dims,definput);
    Offset_Choices = str2double(answer{1});

    clear pro
    % Offset_Number
    for i = 1:Offset_Choices
        pro{i} = strcat('Offset Number',num2str(i));
    end
    prompt = pro;
    title = 'Offset Number';
    dims = [1 50];
    answer = inputdlg(prompt,title,dims);
    for i = 1:Offset_Choices
        Offset_Number(i) = str2double(answer{i});
    end

    % make folder
    for i = 1:length(Amplitude)
        for j = 1:length(Offset_Number)
            whole = 'TSprocessing\Offset\';
            first_folder = num2str(Amplitude(i));
            whole_first_folder = strcat(whole,first_folder);
            mkdir(whole_first_folder);
            second = strcat( 'offset ',num2str(Offset_Number(j))  );
            second_folder = sprintf('%s/%s', whole_first_folder,second);
            mkdir(second_folder)
            third1 = 'Offseted_TS';
            third2 = 'Plot';
            third_folder1 = sprintf('%s/%s', second_folder,third1);
            third_folder2 = sprintf('%s/%s', second_folder,third2);
            mkdir(third_folder1)
            mkdir(third_folder2)
        end
    end

    % offset time
    for i = 1:length(Offset_Number)
        clear pro
        for j = 1:Offset_Number(i)
            pro{j} = strcat('Offset Time',num2str(j));
        end
        prompt = pro;
        title = 'Offset Time';
        dims = [1 50];
        answer = inputdlg(prompt,title,dims);
        for j = 1:Offset_Number(i)
            Offset_Time(i,j) = str2double(answer{j});%Each row means offset time
        end
    end

   %% load data
%     filepath = strcat(cd,'\TSprocessing\Offset\Raw_TS'); 
    filepath = uigetdir('*.*','Please choose a folder'); 
    A = dir(filepath);
    figure
    for i = 1:Amplitude_Choices
        for j = 1:Offset_Choices  
            for k = 3:length(A)
                file = strcat(filepath,'\',A(k).name);
                fid1 = fopen(file);
                data =  textscan(fid1,'%f %f','HeaderLines',1);
                MJD_Time = data{1};
                TimeSeries = data{2};
                fclose(fid1);

                newTimeSeries = TimeSeries;
                row = Offset_Number(j);
                for col = 1:Offset_Number(j)
                    for point = 1:length(MJD_Time)
                        if MJD_Time(point) == Offset_Time(row,col)%                               
                            for p = 1:point-1
                                AfterTimeSeries(p) =  newTimeSeries(p);
                            end
                            for p = point : length(MJD_Time)
                                AfterTimeSeries(p) = newTimeSeries(p) + Amplitude(i);
                            end
                            if col  <  Offset_Number(j)
                                newTimeSeries = AfterTimeSeries;
                            end
                            break
                        end
                    end
                end
            %% save
                afterfile = strcat(cd,'\TSprocessing\Offset\',num2str(Amplitude(i)),'\','offset',num2str(Offset_Number(j)),'\Offseted_TS\',A(k).name);
                fid2 = fopen(afterfile,'w+');
                fprintf(fid2,'# sampling period 1.000000\n');
                for m = 1:length(MJD_Time)
                    fprintf(fid2,'%f\t',MJD_Time(m));
                    fprintf(fid2,'%f\n',AfterTimeSeries(m));
                end
                fclose(fid2);
            %% draw
                day = MJD2Day(MJD_Time);
                p2 = plot(day,TimeSeries','b');
                set(p2,'Color','black','LineWidth',1)
                hold on 
                p = plot(day,AfterTimeSeries');
                set(p,'Color','red','LineWidth',1)
                set(gca,'FontSize',10,'FontName', 'times new roman');
                xlabel('Year')
                ylabel('Amplitude/mm')
                legend('Raw-TS','Offseted-TS')
                set(gca,'FontSize',10,'FontName', 'times new roman');
                hold off 
                pointname = A(k).name;
                pointname(end-3:end) = [];
                graph = strcat(cd,'\TSprocessing\Offset\',num2str(Amplitude(i)),'\','offset',num2str(Offset_Number(j)),'\Plot\',pointname);
                print('-djpeg',graph);
            end
        end
    end

end