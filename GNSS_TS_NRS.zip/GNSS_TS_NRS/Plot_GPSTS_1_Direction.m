function Plot_GPSTS_1_Direction
filepath = uigetdir(strcat(cd,'\example\NoiseReduction'),'Please choose a folder'); 
current = filepath;
A=dir(current);

    for k=3:1:length(A)
        folderE = strcat(current,'\',A(k,1).name);
        fid1 = fopen(folderE);
        data = textscan(fid1,'%f %f','HeaderLines',1);
        timeE = data{1};
        E = data{2};
        fclose(fid1);

        timeE = (timeE-51544)/365.25+2000;

        figure
        plot(timeE,E,'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        
        pointname = A(k,1).name;
        pointname(end-3:end) = [];
        title(pointname)
        hold on
        ylabel('Displacement/mm');
        xlim([timeE(1),timeE(end)])
        hold off
        
        pointname = A(k,1).name;
        graph = strcat(cd,'\TSexpression\Plot-TS\',pointname);
        graph(end-3:end) = [];
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
    end


end