function  CaculateDistance_LL(lat1,lon1,radius)
% example:
% lat1 = 78.067;
% lon1 = 14.250;
% lat2 = 78.229;
% lon2 = 15.395;
% out = gps_distance(lat1,lon1,lat2,lon2)
%     radius = 200;(km)
    fid = fopen('GPS_BLXYZ.txt','r');
    if ( fid == -1 )
        error('can not open file��');
    end
    siteDatbase = textscan(fid,'%s %f %f %f %f %f','headerlines',1);
    database.name = siteDatbase{1};
    database.latitude = siteDatbase{2};
    database.longitude = siteDatbase{3};
    fclose(fid);
% caculate the distance of each site
    for i = 1:length( database.name)
        dis(i) = gps_distance(lat1,lon1,database.latitude(i),database.longitude(i));
    end
    [disdis,local] = sort(dis); 
    % disdis the distance of each GPSsite to the site we choose
    % local is the original location in GPS database
    for k = 1:length(database.name)
        if disdis(k) > radius*1000 % radius is the limited distance
            break
        end
    end
    if k == 1
        msgbox('The radius is too small!');
        return
    end
    
    fid = fopen('GPS distance.txt','w+');
    fprintf(fid,'Site\tDistance(km)\tLatitude\tlongitude\n');
    for j = 1:k-1 % the former k-1 distance is good
        n = local(j);
        fprintf(fid,'%s \t %f \t %f \t %f\n', database.name{n},disdis(j)/1000,...
            database.latitude(n),database.longitude(n));
    end
    fclose(fid);
    msgbox('Finished!');
    open('GPS distance.txt')
end
