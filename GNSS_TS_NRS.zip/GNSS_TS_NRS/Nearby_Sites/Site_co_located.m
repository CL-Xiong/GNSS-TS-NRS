function Site_co_located(GPSsite,Tidesite,radius)
% GPSsite;
% Tidesite;
% GPSsite = '1-GPS.txt';
% Tidesite = '2-Tide.txt';
% radius = 15;% (km)
fid = fopen(GPSsite);
if fid == -1
    error('Can not open the GPSsite file!')
end
siteDatbase  = textscan(fid,'%s %f %f','headerlines',1);
GPSdatabase.name = siteDatbase{1};
GPSdatabase.latitude = siteDatbase{2};
GPSdatabase.longitude = siteDatbase{3};
fclose(fid);

fid = fopen(Tidesite);
if fid == -1
    error('Can not open the Tidesite file!')
end
siteDatbase  = textscan(fid,'%s %f %f','headerlines',1);
Tidedatabase.name = siteDatbase{1};
Tidedatabase.latitude = siteDatbase{2};
Tidedatabase.longitude = siteDatbase{3};
fclose(fid);

siteFound = 0;
fid = fopen('Co-located.txt','w+');
fprintf(fid,'GPS_Site\tGPS_Latitude\tGPS_Longitude\tTide_Site\tTide_Latitude\tTide_Longitude\tDistance(km)\n');
for i = 1:length(GPSdatabase.name)
    for j = 1:length(Tidedatabase.name)
        lat1 = GPSdatabase.latitude(i);
        lon1 = GPSdatabase.longitude(i);
        lat2 = Tidedatabase.latitude(j);
        lon2 = Tidedatabase.longitude(j);
        dis(i,j) = gps_distance(lat1,lon1,lat2,lon2);% each col means distance
        if dis(i,j) < radius*1000
            fprintf(fid,'%s\t',GPSdatabase.name{i});%
            fprintf(fid,'%f\t',GPSdatabase.latitude(i));
            fprintf(fid,'%f\t',GPSdatabase.longitude(i));
            fprintf(fid,'%s\t',Tidedatabase.name{j});
            fprintf(fid,'%f\t',Tidedatabase.latitude(j));
            fprintf(fid,'%f\t',Tidedatabase.longitude(j));
            fprintf(fid,'%f\n',dis(i,j)/1000);
            siteFound = 1;
        end
    end
end
fclose(fid);
if  siteFound == 0
    msgbox('There is not co-located site!')
else
    msgbox('Finished!');
end
open('Co-located.txt');
end