function varargout = Nearby_Sites(varargin)
% NEARBY_SITES MATLAB code for Nearby_Sites.fig
%      NEARBY_SITES, by itself, creates a new NEARBY_SITES or raises the existing
%      singleton*.
%
%      H = NEARBY_SITES returns the handle to a new NEARBY_SITES or the handle to
%      the existing singleton*.
%
%      NEARBY_SITES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NEARBY_SITES.M with the given input arguments.
%
%      NEARBY_SITES('Property','Value',...) creates a new NEARBY_SITES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Nearby_Sites_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Nearby_Sites_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Nearby_Sites

% Last Modified by GUIDE v2.5 07-Aug-2020 21:05:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Nearby_Sites_OpeningFcn, ...
                   'gui_OutputFcn',  @Nearby_Sites_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Nearby_Sites is made visible.
function Nearby_Sites_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Nearby_Sites (see VARARGIN)

% Choose default command line output for Nearby_Sites
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Nearby_Sites wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Nearby_Sites_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.radiobutton1,'value',1);
set(handles.radiobutton2,'value',0);
set(handles.latitudeEdit,'string','');
set(handles.longitudeEdit,'string','');
% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.radiobutton1,'value',0);
set(handles.radiobutton2,'value',1);
set(handles.siteEdit,'string','');

% Hint: get(hObject,'Value') returns toggle state of radiobutton2



function siteEdit_Callback(hObject, eventdata, handles)
% hObject    handle to siteEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of siteEdit as text
%        str2double(get(hObject,'String')) returns contents of siteEdit as a double


% --- Executes during object creation, after setting all properties.
function siteEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to siteEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function longitudeEdit_Callback(hObject, eventdata, handles)
% hObject    handle to longitudeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of longitudeEdit as text
%        str2double(get(hObject,'String')) returns contents of longitudeEdit as a double


% --- Executes during object creation, after setting all properties.
function longitudeEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to longitudeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function latitudeEdit_Callback(hObject, eventdata, handles)
% hObject    handle to longitudeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of longitudeEdit as text
%        str2double(get(hObject,'String')) returns contents of longitudeEdit as a double


% --- Executes during object creation, after setting all properties.
function latitudeEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to longitudeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function radiusEdit_Callback(hObject, eventdata, handles)
% hObject    handle to radiusEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of radiusEdit as text
%        str2double(get(hObject,'String')) returns contents of radiusEdit as a double


% --- Executes during object creation, after setting all properties.
function radiusEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radiusEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 if get(handles.radiobutton1,'value')
     site = get(handles.siteEdit,'string');
     radius = get(handles.radiusEdit,'string');
     CaculateDistance_Site(site,str2double(radius));
 elseif get(handles.radiobutton2,'value')
     lat = get(handles.latitudeEdit,'string');
     latlat = str2double(lat);
     lon = get(handles.longitudeEdit,'string');
     lonlon = str2double(lon);
     radius = get(handles.radiusEdit,'string');
     CaculateDistance_LL(latlat,lonlon,str2double(radius));
 end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open('GPS_BLXYZ.txt')


function GPSEdit_Callback(hObject, eventdata, handles)
% hObject    handle to GPSEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of GPSEdit as text
%        str2double(get(hObject,'String')) returns contents of GPSEdit as a double


% --- Executes during object creation, after setting all properties.
function GPSEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to GPSEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function REdit_Callback(hObject, eventdata, handles)
% hObject    handle to REdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of REdit as text
%        str2double(get(hObject,'String')) returns contents of REdit as a double


% --- Executes during object creation, after setting all properties.
function REdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to REdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TideEdit_Callback(hObject, eventdata, handles)
% hObject    handle to TideEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TideEdit as text
%        str2double(get(hObject,'String')) returns contents of TideEdit as a double


% --- Executes during object creation, after setting all properties.
function TideEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TideEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GPSsite = get(handles.GPSEdit,'string');
Tidesite = get(handles.TideEdit,'string');
radius = get(handles.REdit,'string');
Site_co_located(GPSsite,Tidesite,str2double(radius));
