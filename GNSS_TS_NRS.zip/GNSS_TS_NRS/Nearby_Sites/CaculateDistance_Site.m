function CaculateDistance_Site(site,radius)
%     Load site and BL X Y Z
%     site = 'bjfs';
%     radius = 150;(km)
    fid = fopen('GPS_BLXYZ.txt','r');
    if ( fid == -1 )
        return
    end
    siteDatbase = textscan(fid,'%s %f %f %f %f %f','headerlines',1);
    database.name = siteDatbase{1};
    database.latitude = siteDatbase{2};
    database.longitude = siteDatbase{3};
    database.X = siteDatbase{4};
    database.Y = siteDatbase{5};
    database.Z = siteDatbase{6};
    fclose(fid);
    % i means the location of site in site database
    siteFound = 0;
    for i = 1:length(database.name)
        if strcmp(site,database.name{i})
            siteFound = 1;
            break
        end
    end
    if siteFound == 0
        error('No such a site')
    end
    % caculate all distance between two point
    for j = 1:length(database.name)
        if j ~= i
            resiX = database.X(i) - database.X(j);
            resiY = database.Y(i) - database.Y(j);
            resiZ = database.Z(i) - database.Z(j);
            dis(j) = sqrt( resiX^2 + resiY^2 + resiZ^2 );
        elseif j == i
            dis(j) = inf;
        end
    end
    [disdis,local] = sort(dis); 
    % disdis the distance of each GPSsite to the site we choose
    % local is the original location in GPS database
    for k = 1:length(database.name)
        if disdis(k) > radius*1000 % radius is the limited distance
            break
        end
    end
    if k == 1
        msgbox('The radius is too small');
        return
    end
    pa = 'Nearby_Sites\GPS distance.txt';
    fid = fopen(pa,'w+');
    fprintf(fid,'Site\tDistance(km)\tLatitude\tlongitude\n');
    for j = 1:k-1 % the former k-1 distance is good
        n = local(j);
        fprintf(fid,'%s \t %f \t %f \t %f\n', database.name{n},disdis(j) / 1000,...
            database.latitude(n),database.longitude(n));
    end
    fclose(fid);
    open(pa)
end