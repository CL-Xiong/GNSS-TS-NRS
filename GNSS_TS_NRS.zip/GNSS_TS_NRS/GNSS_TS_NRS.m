function varargout = GNSS_TS_NRS(varargin)

% GNSS_TS_NRS MATLAB code for GNSS_TS_NRS.fig
%      GNSS_TS_NRS, by itself, creates a new GNSS_TS_NRS or raises the existing
%      singleton*.
%      H = GNSS_TS_NRS returns the handle to a new GNSS_TS_NRS or the handle to
%      the existing singleton *.
%      GNSS_TS_NRS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GNSS_TS_NRS.M with the given input arguments.
%      GNSS_TS_NRS('Property','Value',...) creates a new GNSS_TS_NRS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GNSS_TS_NRS_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GNSS_TS_NRS_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GNSS_TS_NRS

% Last Modified by GUIDE v2.5 02-Sep-2020 17:18:33

% Begin initialization code - DO NOT EDIT
clc
disp('This is the first version of GNSS-TS-NRS, An Open-source MATLAB Based GNSS Time Series Noise Reduction Software')
disp('If with any questions/suggestions on our software, please contact cl-xiong@qq.com and hexiaoxingsgg@gmail.com')
disp('We will be happy to hear any precious advice from you.Thank you!')
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GNSS_TS_NRS_OpeningFcn, ...
                   'gui_OutputFcn',  @GNSS_TS_NRS_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GNSS_TS_NRS is made visible.
function GNSS_TS_NRS_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GNSS_TS_NRS (see VARARGIN)

% Choose default command line output for GNSS_TS_NRS
movegui(gcf,'center');
clear global
opt_popRMS = {'one direction','three directions'}; %%%
opt_popCorr = {'one direction','three directions'};
opt_popPlotTS = {'one direction','three directions'};
opt_popBox = {'hold on','hold off'};
opt_popPSD = {'hold on','hold off','three directions'};
opt_popDistribution = {'alpha','norm','both'};
opt_popSLREMD = {'Plot','No Plot'};
opt_popSLREEMD = {'Plot','No Plot'};

set(handles.popRMS,'string',opt_popRMS);
set(handles.popCorr,'string',opt_popCorr);
set(handles.popPlotTS,'string',opt_popPlotTS);
set(handles.popBox,'string',opt_popBox);
set(handles.popPSD,'string',opt_popPSD);
set(handles.popDistribution,'string',opt_popDistribution);

set(handles.popViolin,'string',opt_popBox);
% set(handles.popSLREMD,'string',opt_popSLREMD);
% set(handles.popSLREEMD,'string',opt_popSLREEMD);


handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
% UIWAIT makes GNSS_TS_NRS wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GNSS_TS_NRS_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
movegui(gcf,'center');
varargout{1} = handles.output;
GUI_ShowAnnouncement



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in NRS_Close.
function NRS_Close_Callback(hObject, eventdata, handles)
% hObject    handle to NRS_Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% show NRS_Close
for i = 1:gcf
     close(figure(i));
end

% --- Executes on mouse press over figure background.
function figure1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function filename_Callback(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filename as text
%        str2double(get(hObject,'String')) returns contents of filename as a double


% --- Executes during object creation, after setting all properties.
function filename_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Load_Data.
function Load_Data_Callback(hObject, eventdata, handles)
GlobalConstant
choose_text{1}='Which is the data format you want to load,three directions or one direction? ';
choose_text{2}='Please choose';
Choose =  (questdlg(choose_text, 'Choice', 'Three directions','One direction','Three direction'));
switch Choose
    case 'Three directions'
        Choose_Index = 3;
        Load_Data(Choose_Index)
    case  'One direction'
        Choose_Index = 1;
        Load_Data(Choose_Index)
end
   
% --- Executes on button press in Start.
function Start_Callback(hObject, eventdata, handles)

GlobalConstant
if  Simulated_Index == 1 & Noise_Index == 1
    RawData = Simulated_Data + Noise;
    Choose_Index = 1;
    Plot_Simulated;
elseif  Simulated_Index == 1 
    RawData = Simulated_Data;
    Plot_Simulated;
    Choose_Index = 1;
end

%%  Method1 EMD
if get(handles.Method1_Checkbox,'value');
    [data1 Pk1 leng1] = Method1(RawData); 
    Plot_Method1(RawData,data1,Pk1,leng1)
    if isempty(Simulated_Data)
        Pre_Ass_Method1(RawData,data1);
    else
        Pre_Ass_Method1(RawData,data1,Simulated_Data);
    end
end
%% Method2 reduce the effect of signal noise aliasing
if get(handles.Method2_Checkbox,'value');   
    data2  = Method2(RawData);
    Plot_Method2(RawData,data2)
    if isempty(Simulated_Data)
        Pre_Ass_Method2( RawData,data2);
    else
        Pre_Ass_Method2(RawData,data2,Simulated_Data);
    end
end
%% Method3 based on EMD ,average period ,and energy density
%   other discriminated method ,not COF
if get(handles.Method3_Checkbox,'value');
    data3  = Method3(RawData);
    Plot_Method3(RawData,data3)
    if isempty(Simulated_Data)
         Pre_Ass_Method3(RawData,data3);
    else
         Pre_Ass_Method3(RawData,data3,Simulated_Data);
    end
end
%% Method4 
if get(handles.Method4_Checkbox,'value');
    data4 = Method4(RawData);
    Plot_Method4(RawData,data4)
    if isempty(Simulated_Data)
        Pre_Ass_Method4(RawData,data4);
    else
        Pre_Ass_Method4(RawData,data4,Simulated_Data);
    end
end
%% Method5 EEMD
if get(handles.Method5_Checkbox,'value');
    [data5 Pk5 leng5] = Method5(RawData); 
    Plot_Method5(RawData,data5,Pk5,leng5)
    if isempty(Simulated_Data)
        Pre_Ass_Method5(RawData,data5);
    else
        Pre_Ass_Method5(RawData,data5,Simulated_Data);
    end
end
%%
data = [];index = [];
    if exist('data1')
        data = [data,data1];index = [index;1];
    end
    if exist('data2')
        data = [data,data2];index = [index;2];
    end
    if exist('data3')
        data = [data,data3];index = [index;3];
    end
    if exist('data4')
        data = [data,data4];index = [index;4];
    end
    if exist('data5')
        data = [data,data5];index = [index;5];
    end
Plot_All(data,index)

% --- Executes on button press in Method1_Checkbox.
function Method1_Checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to Method1_Checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Method1_Checkbox


% --- Executes on button press in Method2_Checkbox.
function Method2_Checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to Method2_Checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Method2_Checkbox


% --- Executes on button press in Method3_Checkbox.
function Method3_Checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to Method3_Checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Method3_Checkbox


% --- Executes on button press in Method4_Checkbox.
function Method4_Checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to Method4_Checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of Method4_Checkbox


% --- Executes on button press in WN_Noise.
function WN_Noise_Callback(hObject, eventdata, handles)
% hObject    handle to WN_Noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GlobalConstant
prompt = {'WN power(dB)'};
title = 'WN parameter';
dims = [1 35];
definput = {'4'};
answer = inputdlg(prompt,title,dims,definput);
power = str2num(answer{1});  
Noise = wgn(1,Data_Length,power,'linear');
Noise = Noise';
Noise_Index = 1;

% --- Executes on button press in WN_Plus_PL_Noise.
function WN_Plus_PL_Noise_Callback(hObject, eventdata, handles)
% hObject    handle to WN_Plus_PL_Noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GlobalConstant
prompt = {'PL Amplitude(mm)','WN Amplitude(mm)','Spectrum Index'};
title = 'PL+WN Parameters';
definput = {'0.02','5','-1.2'};
dims = [1 35];
answer = inputdlg(prompt,title,dims,definput);
pl_jump = str2double(answer{1});
wn_jump = str2double(answer{2});
spectrum_index = str2double(answer{3});
Noise = createPLplusWN(Data_Length,pl_jump,wn_jump,spectrum_index);
Noise_Index = 1;




function Data_Length_Callback(hObject, eventdata, handles)
% hObject    handle to Data_Length (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Data_Length as text
%str2double(get(hObject,'String')) returns contents of Data_Length as a double


% --- Executes during object creation, after setting all properties.
function Data_Length_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Data_Length (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PerFun.
function PerFun_Callback(hObject, eventdata, handles)
Simulated_PerFun


% --- Executes during object creation, after setting all properties.
function text6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in Stack_Flitering.
function Stack_Flitering_Callback(hObject, eventdata, handles)
% hObject    handle to Stack_Flitering (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CME_StackFlitering

% --- Executes on button press in Distance_Weighted.
function Distance_Weighted_Callback(hObject, eventdata, handles)
% hObject    handle to Distance_Weighted (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CME_DistanceWeighted

% --- Executes on button press in COR.
function COR_Callback(hObject, eventdata, handles)
% hObject    handle to COR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popCorr,'value');
choice = get(handles.popCorr,'string');
CORR(choice{val})



% --- Executes on button press in PSD.
function PSD_Callback(hObject, eventdata, handles)
% hObject    handle to PSD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
PSD


% --- Executes on button press in Plot_GPSTS.
function Plot_GPSTS_Callback(hObject, eventdata, handles)
% hObject    handle to Plot_GPSTS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popPlotTS,'value');
choice = get(handles.popPlotTS,'string');
Plot_GPSTS(choice{val})


% --- Executes on button press in Outlier3.
function Outlier3_Callback(hObject, eventdata, handles)
% hObject    handle to Outlier3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
OD_nSigma

% --- Executes on button press in Outlier5.
function Outlier5_Callback(hObject, eventdata, handles)
% hObject    handle to Outlier5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
OD_5Sigma

% --- Executes on button press in MAD.
function MAD_Callback(hObject, eventdata, handles)
% hObject    handle to MAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
OD_MAD

% --- Executes on button press in IQR.
function IQR_Callback(hObject, eventdata, handles)
% hObject    handle to IQR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
OD_nIQR


% --- Executes on button press in MAD.
% function MAD_Callback(hObject, eventdata, handles)
% % hObject    handle to MAD (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% OD_MAD


% --- Executes on button press in RMS.
function RMS_Callback(hObject, eventdata, handles)
% hObject    handle to RMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popRMS,'value');
choice = get(handles.popRMS,'string');
RMS_All(choice{val})



% --- Executes on button press in Clear.
function Clear_Callback(hObject, eventdata, handles)
% hObject    handle to Clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear global
set(handles.Method1_Checkbox,'value',0)
set(handles.Method2_Checkbox,'value',0)
set(handles.Method3_Checkbox,'value',0)
set(handles.Method4_Checkbox,'value',0)
set(handles.Method5_Checkbox,'value',0)



% --- Executes on button press in WeightedStack.
function WeightedStack_Callback(hObject, eventdata, handles)
% hObject    handle to WeightedStack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CME_StackFliteringWeighted

% --- Executes on button press in CorrWeightedStack.
function CorrWeightedStack_Callback(hObject, eventdata, handles)
% hObject    handle to CorrWeightedStack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CME_CorrelationWeightedStackingFiltering


% --- Executes on button press in SeasonalSignals.
function SeasonalSignals_Callback(hObject, eventdata, handles)
% hObject    handle to SeasonalSignals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Simulated_SeasonalSignals


% --------------------------------------------------------------------
function ExtractIMF_Callback(hObject, eventdata, handles)
% hObject    handle to ExtractIMF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on button press in SLR_EMD.
function SLR_EMD_Callback(hObject, eventdata, handles)
% hObject    handle to SLR_EMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popSLREMD,'value');
choice = get(handles.popSLREMD,'string');
SLR_EMD(choice{val})



% --------------------------------------------------------------------
function FormatTool_Callback(hObject, eventdata, handles)
% hObject    handle to FormatTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
FormatTool


% --- Executes on button press in Method5_Checkbox.
function Method5_Checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to Method5_Checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Method5_Checkbox


% --- Executes on button press in FormatTool.
function pushbutton27_Callback(hObject, eventdata, handles)
% hObject    handle to FormatTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Exp_PSD.
function Exp_PSD_Callback(hObject, eventdata, handles)
% hObject    handle to Exp_PSD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% ��������������
val = get(handles.popPSD,'value');
choice = get(handles.popPSD,'string');
PSD(choice{val})

% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in CME_Start.
function CME_Start_Callback(hObject, eventdata, handles)
% hObject    handle to CME_Start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global option namelist
if get(handles.radiobutton1,'value')
    option = 1;
end
if get(handles.radiobutton2,'value')
    option = 2;
end
if get(handles.radiobutton3,'value')
    option = 3;
end
if get(handles.radiobutton4,'value')
    option = 4;      
end
if get(handles.radiobutton5,'value')
    option = 5;      
end
if option
    filepath = uigetdir(strcat(cd,'\example\CME'),'Please choose TS folder'); 
    if get(handles.radiobutton4,'value') 
        filepath1 = uigetdir(strcat(cd,'\example\CME'),'Please choose distance folder'); 
    end
    if get(handles.radiobutton1,'value')
        namelist = CME_StackFlitering(filepath);
    end
    if get(handles.radiobutton2,'value')
        namelist = CME_StackFliteringWeighted(filepath);
    end
    if get(handles.radiobutton3,'value')
        namelist = CME_CorrelationWeightedStackingFiltering(filepath);
    end
    if get(handles.radiobutton4,'value') 
        namelist = CME_DistanceWeighted(filepath,filepath1); 
    end
    if get(handles.radiobutton5,'value') 
        namelist = CME_PCA(filepath); 
    end
end

% --- Executes on button press in pushbutton33.
function pushbutton33_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open('user-manual for GNSS-TS-NRS.pdf')

% --- Executes on button press in CME_ViewRMS.
function CME_ViewRMS_Callback(hObject, eventdata, handles)
% hObject    handle to CME_ViewRMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global option namelist percentage CME_method
% dname = [cd '\CME\RMS.txt'];
k = 1;
CME_method = [];
if option
    if get(handles.radiobutton1,'value')
        dname = [cd '\CME\Stack_Flitering\RMS1.txt'];
        filepa{k} = dname;
        k = k+1;
        CME_method = [CME_method 1];
    end
    if get(handles.radiobutton2,'value')
        dname = [cd '\CME\Stack_Flitering_Weighted\RMS2.txt'];
        filepa{k} = dname;
        k = k+1;
        CME_method = [CME_method 2];
    end
    if get(handles.radiobutton3,'value')
        dname = [cd '\CME\Correlation_Weighted_Stacking_Filtering\RMS3.txt'];
        filepa{k} = dname;
        k = k+1;
        CME_method = [CME_method 3];
    end
    if get(handles.radiobutton4,'value') 
        dname = [cd '\CME\Distance_Weighted\RMS4.txt'];
        filepa{k} = dname;
        k = k+1;
        CME_method = [CME_method 4];
    end
    if get(handles.radiobutton5,'value') 
        dname = [cd '\CME\PCA\RMS5.txt'];
        filepa{k} = dname;
        k = k+1;
        CME_method = [CME_method 5];
    end
end
percentage = CME_ViewRms(filepa,CME_method,namelist)


% --- Executes on button press in CME_ViewChange.
function CME_ViewChange_Callback(hObject, eventdata, handles)
% hObject    handle to CME_ViewChange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global percentage CME_method namelist
CME_ViewChange(percentage,CME_method,namelist)


% --- Executes on button press in Exp_Dis.
function Exp_Dis_Callback(hObject, eventdata, handles)
% hObject    handle to Exp_Dis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popDistribution,'value');
choice = get(handles.popDistribution,'string');
Distribution(choice{val})


% --- Executes on button press in Offset.
function Offset_Callback(hObject, eventdata, handles)
% hObject    handle to Offset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Offset

% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Exp_Boxplot.
function Exp_Boxplot_Callback(hObject, eventdata, handles)
% hObject    handle to Exp_Boxplot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popBox,'value');
choice = get(handles.popBox,'string');
Boxplot(choice{val})



% --- Executes on button press in ViewFolder.
function ViewFolder_Callback(hObject, eventdata, handles)
% hObject    handle to ViewFolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winopen(cd)

% --- Executes on button press in SLR_EEMD.
function SLR_EEMD_Callback(hObject, eventdata, handles)
% hObject    handle to SLR_EEMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popSLREMD,'value');
choice = get(handles.popSLREMD,'string');
SLR_EEMD(choice{val})

% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on selection change in popRMS.
function popRMS_Callback(hObject, eventdata, handles)
% hObject    handle to popRMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popRMS contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popRMS


% --- Executes during object creation, after setting all properties.
function popRMS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popRMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popPSD.
function popPSD_Callback(hObject, eventdata, handles)
% hObject    handle to popPSD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popPSD contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popPSD


% --- Executes during object creation, after setting all properties.
function popPSD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popPSD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popBox.
function popBox_Callback(hObject, eventdata, handles)
% hObject    handle to popBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popBox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popBox


% --- Executes during object creation, after setting all properties.
function popBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popPlotTS.
function popPlotTS_Callback(hObject, eventdata, handles)
% hObject    handle to popPlotTS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popPlotTS contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popPlotTS


% --- Executes during object creation, after setting all properties.
function popPlotTS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popPlotTS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popCorr.
function popCorr_Callback(hObject, eventdata, handles)
% hObject    handle to popCorr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popCorr contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popCorr


% --- Executes during object creation, after setting all properties.
function popCorr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popCorr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popDistribution.
function popDistribution_Callback(hObject, eventdata, handles)
% hObject    handle to popDistribution (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popDistribution contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popDistribution


% --- Executes during object creation, after setting all properties.
function popDistribution_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popDistribution (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popSLREMD.
function popSLREMD_Callback(hObject, eventdata, handles)
% hObject    handle to popSLREMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popSLREMD contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popSLREMD


% --- Executes during object creation, after setting all properties.
function popSLREMD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popSLREMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popSLREEMD.
function popSLREEMD_Callback(hObject, eventdata, handles)
% hObject    handle to popSLREEMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popSLREEMD contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popSLREEMD


% --- Executes during object creation, after setting all properties.
function popSLREEMD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popSLREEMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Exp_Violinplot.
function Exp_Violinplot_Callback(hObject, eventdata, handles)
% hObject    handle to Exp_Violinplot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.popViolin,'value');
choice = get(handles.popViolin,'string');
Violinplot(choice{val})

% --- Executes on selection change in popViolin.
function popViolin_Callback(hObject, eventdata, handles)
% hObject    handle to popViolin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popViolin contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popViolin


% --- Executes during object creation, after setting all properties.
function popViolin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popViolin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton41.
function pushbutton41_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton41 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Nearby_Sites
% --- Executes on button press in pushbutton42.
function pushbutton42_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton42 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('Sorry,this module is currently developing!')
