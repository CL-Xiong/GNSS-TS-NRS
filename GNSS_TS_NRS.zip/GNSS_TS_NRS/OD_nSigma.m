function OD_nSigma
%% Load data
%parameter input:
%multiple*Sigma
    prompt = {'multiple*Sigma'};
    title = 'criterion';
    dims = [1 35];
    definput = {'5'};
    answer = inputdlg(prompt,title,dims,definput);
    mult = str2double(answer{1});% multiple
%     mult = 4;

    filepath = uigetdir(strcat(cd,'\example'),'Please choose a folder'); 
    current = filepath;
    A=dir(current);
    percent = [];% the precentage of outlier
    for ss=3:3:length(A)
        folder = strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        data =  textscan(fid,'%f%f','HeaderLines',1);
        MJD_Time = data{1};
        E = data{2};
        fclose(fid);

        folder =strcat(current,'\',A(ss+1,1).name);
        fid = fopen(folder);
        data = textscan(fid, '%f%f','HeaderLines',1);
        N = data{2};
        fclose(fid);

        folder=strcat(current,'\',A(ss+2,1).name);
        fid = fopen(folder);
        data = textscan(fid,'%f%f','HeaderLines',1);
        U = data{2};  
        fclose(fid);
%%  
        [a b] =size(E);
        datax = E;
        datay = N;
        dataz = U;
        sumx = sum(datax);
        sumy = sum(datay);
        sumz = sum(dataz);
        meanx = sumx/a;
        meany = sumy/a;
        meanz = sumz/a;

        sum_s_deltax53 = 0;
        sum_s_deltay53 = 0;
        sum_s_deltaz53 = 0;
        for k = 1:a
            sum_s_deltax53 = sum_s_deltax53 + (datax(k,1)-meanx)^2;
            sum_s_deltay53 = sum_s_deltay53 + (datay(k,1)-meany)^2;
            sum_s_deltaz53 = sum_s_deltaz53 + (dataz(k,1)-meanz)^2;
        end
        sigmax53 = (sum_s_deltax53/a)^0.5;
        sigmay53 = (sum_s_deltay53/a)^0.5;
        sigmaz53 = (sum_s_deltaz53/a)^0.5;

        idx3=[];
        idy3=[];
        idz3=[];
        for i = 1:a
            if abs(datax(i,1)-meanx)<mult*sigmax53 && abs(datay(i,1)-meany)<mult*sigmay53 && abs(dataz(i,1)-meanz)<mult*sigmaz53
                afterdatax3(i,1) = datax(i,1);
                afterdatay3(i,1) = datay(i,1);
                afterdataz3(i,1) = dataz(i,1);
            else
                idx3 = [idx3,i];
                idy3 = [idy3,i];
                idz3 = [idz3,i];
                afterdatax3(i,1) = Inf;
                afterdatay3(i,1) = Inf;
                afterdataz3(i,1) = Inf;
            end
        end
%% write file
        fid4 = strcat(cd,'\TSprocessing\OutlierDetection\Sigma','\',A(ss,1).name);
        txt4 = fopen(fid4, 'w');
        fprintf(txt4,'# sampling period 1.0\n');
        for j = 1:length(E)
            if afterdatax3(j,1) ~= inf
              fprintf(txt4,'%8.2f\t',MJD_Time(j));
              fprintf(txt4,'%8.2f\t\n',afterdatax3(j,1));
            end
        end
        fclose(txt4);

        fid4 = strcat(cd,'\TSprocessing\OutlierDetection\Sigma','\',A(ss+1,1).name);
        txt4 = fopen(fid4, 'w');
        fprintf(txt4,'# sampling period 1.0\n');
        for j = 1:length(N)
            if afterdatay3(j,1) ~= inf
                fprintf(txt4,'%8.2f\t',MJD_Time(j));
                fprintf(txt4,'%8.2f\t\n',afterdatay3(j,1));
            end
        end
        fclose(txt4);

        fid4 = strcat(cd,'\TSprocessing\OutlierDetection\Sigma','\',A(ss+2,1).name);
        txt4 = fopen(fid4, 'w');
        fprintf(txt4,'# sampling period 1.0\n');
        for j = 1:length(U)
            if afterdataz3(j,1) ~= inf
                fprintf(txt4,'%8.2f\t',MJD_Time(j));
                fprintf(txt4,'%8.2f\t\n',afterdataz3(j,1));
            end
        end
        fclose(txt4);
%%
        idx3graph = [];
        for i = 1:length(E)
            if abs(datax(i,1)-meanx)<mult*sigmax53
               afterdatax3graph(i,1) = datax(i,1);
            else
                idx3graph = [idx3graph,i];
                afterdatax3graph(i,1) = Inf;
            end
        end
        
        idy3graph=[];
        for i = 1:length(N)
            if abs(datay(i,1)-meany)<mult*sigmay53
               afterdatay3graph(i,1) = datay(i,1);
            else
                idy3graph = [idy3graph,i];
                afterdatay3graph(i,1) = Inf;
            end
        end
       
        idz3graph=[];
        for i = 1:length(U)
            if abs(dataz(i,1)-meanz)<mult*sigmaz53
               afterdataz3graph(i,1) = dataz(i,1);
            else
                idz3graph = [idz3graph,i];
                afterdataz3graph(i,1) = Inf;
            end
        end
        
       %% draw picture
        % obtain station name
        pointname = A(ss,1).name;
        pointname(end-5:end) = [];
        pn{ss/3} = pointname;
        
        time = MJD2Day( MJD_Time);
        figure
        subplot(3,1,1)
        
        plot(time,datax);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        hold on;
        plot(time(idx3graph'),datax(idx3graph),'c*');
        ylabel('E[mm]');
        legend('Original','3Sigma');
        hold off;
%         title(pointname);

        subplot(3,1,2)
        plot(time,datay);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        hold on;
        plot(time(idy3graph'),datay(idy3graph),'c*');
        ylabel('N[mm]');
        legend('Original','3Sigma');
        hold off;
        
        subplot(3,1,3)
        plot(time,dataz);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        hold on;
        plot(time(idz3graph'),dataz(idz3graph),'c*');
        ylabel('U[mm]');
        xlabel('Year');
        legend('Original','3Sigma');
        hold off;
        
        percent3 = length(idx3)/length(datax);
        percent = [percent;percent3];
        
        graph = strcat(cd,'\TSprocessing\OutlierDetection\Sigma\graph','\',A(ss,1).name);
        graph(end-5:end) = [];
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
    end
    fileoutput = strcat(cd,'\TSprocessing\OutlierDetection\Sigma\percentage of OD.txt');
    fid = fopen(fileoutput,'wt');
%     mult
    fprintf(fid,'The crition is %dSigma\n',mult);
    fprintf(fid,'%s\t%s\n','PointName ','%');
    for i = 1:length(pn)
        fprintf(fid,'%s\t',mat2str(pn{i}));
        fprintf(fid,'%6.3f\t\n',percent(i)*100);
    end
    fclose(fid);
    open(fileoutput);
end

