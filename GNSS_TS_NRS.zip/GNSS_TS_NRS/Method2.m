function data  = Method2( RawData )
%   This method aims to reduce the effect of signal noise aliasing
%   Pk is the coefficient of association of each IMF with RawData
%   Renumber is the number of iterations
%   a folder named Method2 which is created in GUImain,
%   in current direction to save data

    GlobalConstant
    if Choose_Index == 1
        ReNumber = 1;
        data = zeros(length(RawData),1);
        Reserve_Data = RawData;
        Reassign = zeros(length(Reserve_Data),1);
         while  1
           allmode = eemd( Reserve_Data,0,1);
           [coll row] = size(allmode);
           for mmm = 1:row-1
               imf{mmm} = allmode(:,mmm+1)';
           end
           %%
            if length(imf) < 3 
                break      
            end
            %   Compute the correlation
            for i = 1:length(imf)
              Pk(i,ReNumber) = relative(imf{i},Reserve_Data); 
            end
            %   otain the first minimum point
            lowpeak = findpeaks( -( Pk(:,ReNumber) ) );
            %   circulation should quit when the peaks is null
            if isempty(lowpeak) | lowpeak == (length(imf)+1 )
%                 msgbox('The correlation value has been monotonic')
                break   
            end
            k(ReNumber) = lowpeak(1);
    
            %%    
            %   Low-frequency signal assemble
            for i = ( k(ReNumber)+1 ) : length(imf)
                data = data+(imf{i})';
            end
            %   High-frequency signal assemble
            Reassign = zeros(length(Reserve_Data),1);
    
            for j = 2:k(ReNumber)
               Reassign = Reassign+(imf{j})';
            end
            %   reassign number+1
            Reserve_Data = Reassign;
            ReNumber = ReNumber+1;
            lowpeak = [];
         end
    end
%%
    if Choose_Index == 3
        data = zeros(length(RawData),3);
        for ori = 1:3
            ReNumber(ori) = 1;
            Data = RawData(:,ori);
            Reserve_Data = Data;
            Reassign = zeros(length(Reserve_Data),1);
             while  1
               allmode = eemd( Reserve_Data,0,1);
               [coll row] = size(allmode);
               for mmm = 1:row-1
                   imf{mmm} = allmode(:,mmm+1)';
               end
                if length(imf) < 3 
                    break
                end
                %   Compute the correlation
                for i = 1:length(imf)
                     Pk(i,ReNumber(ori)) = relative(imf{i},Reserve_Data); 
                end
                %   otain the first minimum point
                lowpeak = findpeaks( -( Pk(:,ReNumber(ori)) ) );
                %   circulation should quit when the peaks is null
                if isempty(lowpeak) | lowpeak == (length(imf)+1 )
                    break   
                end
                k( ReNumber(ori) ) = lowpeak(1);

                %%    
                %   Low-frequency signal assemble
                for i = ( k( ReNumber(ori) )+1 ) : length(imf)
                    data(:,ori) = data(:,ori)+(imf{i})';
                end
                %   High-frequency signal assemble
                Reassign = zeros(length(Reserve_Data),1);

                for j = 2:k(ReNumber(ori))
                   Reassign = Reassign+(imf{j})';
                end
                %   reassign number+1
                Reserve_Data = Reassign;
                ReNumber(ori) = ReNumber(ori)+1;
                lowpeak = [];
             end
        end
    end
 %% save data
   % RawData and data 
   % Pk
   % ReNumber
    ReNumber = ReNumber-1;
    dname = [cd '\NoiseReduction\Method2'];
    fn = '\\Pk.txt';
    save ([dname fn],'Pk','-ascii')
    fn = '\\ReNumber.txt';
    save ([dname fn],'ReNumber','-ascii')
    
    for i = 1:Choose_Index
        dname = [cd '\NoiseReduction\Method2'];
        if Simulated_Index == 1
            newfn{i} = 'Simulated.mom';
        end
        fn = newfn{i};
        fid = fopen([dname '\' fn],'w+');
        fprintf(fid,'# sampling period 1.0\n');
        for j = 1:length(MJD_Time)
             fprintf(fid,'%f\t',MJD_Time(j,i));
             fprintf(fid,'%f\n',data(j,i));
        end
        fclose(fid);
    end
 
end

