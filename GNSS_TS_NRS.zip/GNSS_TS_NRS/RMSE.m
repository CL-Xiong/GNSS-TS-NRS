function RMSE = RMSE(IMF,RawData)
%   Compute the RMSE
[m n] = size(IMF);
if m==1
    IMF=IMF';
end
summation = sum ( ( IMF-RawData ).^2) / length(RawData);
RMSE = sqrt(summation);
end
