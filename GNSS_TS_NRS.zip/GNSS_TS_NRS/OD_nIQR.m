function OD_nIQR
%% Quartile algorithm
    clear
    clc
    prompt = {'multiple*IQR'};
    title = 'criterion';
    dims = [1 35];
    definput = {'3'};
    answer = inputdlg(prompt,title,dims,definput);
    mult = str2double(answer{1});% multiple
    
    filepath = uigetdir(strcat(cd,'\example'),'Please choose a folder'); 
    current = filepath;
    A=dir(current);
    percent = [];
    for ss = 3:3:length(A)
        folder = strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        data =  textscan(fid,' %f%f','HeaderLines',1);
        MJD_Time = data{1};
        E = data{2};
        fclose(fid);

        folder =strcat(current,'\',A(ss+1,1).name);
        fid = fopen(folder);
        data = textscan(fid, '%f%f','HeaderLines',1);
        N = data{2};
        fclose(fid);

        folder=strcat(current,'\',A(ss+2,1).name);
        fid = fopen(folder);
        data = textscan(fid, '%f%f','HeaderLines',1);
        U = data{2};  
        fclose(fid);

        datax = E;
        datay = N;
        dataz = U;

    %Quartile algorithm
        % calculate higher quartile
        Q1x=prctile(datax,25);
        Q1y=prctile(datay,25);
        Q1z=prctile(dataz,25);
        % calculate lower quartile
        Q2x=prctile(datax,75);
        Q2y=prctile(datay,75);
        Q2z=prctile(dataz,75);
        % interquartile range
        xiqr=iqr(datax);
        yiqr=iqr(datay);
        ziqr=iqr(dataz);

        idxiqr = [];
        idyiqr = [];
        idziqr = [];
        for i = 1:length(E)
            if datax(i,1)>Q1x-mult*xiqr&&datax(i,1)<Q2x+mult*xiqr&&datay(i,1)>Q1y-mult*yiqr&&datay(i,1)<Q2y+mult*yiqr&&dataz(i,1)>Q1z-mult*ziqr&&dataz(i,1)<Q2z+mult*ziqr
                afterdataxiqr(i,1) = datax(i,1);
                afterdatayiqr(i,1) = datay(i,1);
                afterdataziqr(i,1) = dataz(i,1);
            else
                idxiqr = [idxiqr,i];
                idyiqr = [idyiqr,i];
                idziqr = [idziqr,i];
                afterdataxiqr(i,1) = Inf;
                afterdatayiqr(i,1) = Inf;
                afterdataziqr(i,1) = Inf;
            end
        end
%% write file
        fid4=strcat(cd,'\TSprocessing\OutlierDetection\IQR','\',A(ss,1).name);
        txt4 = fopen(fid4, 'w');
        fprintf(txt4,'# sampling period 1.0\n');
        for j = 1:length(E)
           if afterdataxiqr(j) ~= inf
              fprintf(txt4,'%8.2f\t',MJD_Time(j));
              fprintf(txt4,'%8.2f\t\n',afterdataxiqr(j));
            end
        end
        fclose(txt4);
        
        fid4 = strcat(cd,'\TSprocessing\OutlierDetection\IQR','\',A(ss+1,1).name);
        txt4 = fopen(fid4, 'w');
        fprintf(txt4,'# sampling period 1.0\n');
        for j = 1:length(N)
            if afterdatayiqr(j,1) ~= inf
                fprintf(txt4,'%8.2f\t',MJD_Time(j));
                fprintf(txt4,'%8.2f\t\n',afterdatayiqr(j,1));
            end
        end
        fclose(txt4);

        fid4 = strcat(cd,'\TSprocessing\OutlierDetection\IQR','\',A(ss+2,1).name);
        txt4 = fopen(fid4, 'w');
        fprintf(txt4,'# sampling period 1.0\n');
        for j = 1:length(U)
            if afterdataziqr(j,1) ~= inf
                fprintf(txt4,'%8.2f\t',MJD_Time(j));
                fprintf(txt4,'%8.2f\t\n',afterdataziqr(j,1));
            end
        end
        fclose(txt4);
%%
        idxiqrgraph = [];
        for i = 1:length(E)
            if datax(i,1)>Q1x-mult*xiqr&&datax(i,1)<Q2x+mult*xiqr
                afterdataxiqrgraph(i,1) = datax(i,1);
            else
                idxiqrgraph = [idxiqrgraph,i];
                afterdataxiqrgraph(i,1) = Inf;
            end
        end
        idyiqrgraph = [];
        for i = 1:length(N)
            if datay(i,1)>Q1y-mult*yiqr&&datay(i,1)<Q2y+mult*yiqr
               afterdatayiqrgraph(i,1) = datay(i,1);
            else
                idyiqrgraph = [idyiqrgraph,i];
                afterdatayiqrgraph(i,1) = Inf;
            end
        end
        idziqrgraph=[];
        for i = 1:length(U)
            if dataz(i,1)>Q1z-mult*ziqr&&dataz(i,1)<Q2z+mult*ziqr
               afterdataziqrgraph(i,1) = dataz(i,1);
            else
                idziqrgraph = [idziqrgraph,i];
                afterdataziqrgraph(i,1) = Inf;
            end
        end
       %% draw picture
        % obtain station name
        pointname = A(ss,1).name;
        pointname(end-5:end) = [];
        pn{ss/3} = pointname;
        
        
        time = MJD2Day( MJD_Time);
        figure
        subplot(3,1,1)
        plot(time,datax);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        hold on;
        plot(time(idxiqrgraph'),datax(idxiqrgraph),'c*');
        ylabel('E[mm]');
        legend('Original','3IQR');
        hold off;
        
                
%         title(pointname)
        subplot(3,1,2)
        plot(time,datay);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        hold on;
        plot(time(idyiqrgraph'),datay(idyiqrgraph),'c*');
        ylabel('N[mm]');
        legend('Original','3IQR');
        hold off;
        
        subplot(3,1,3)
        plot(time,dataz);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        hold on;
        plot(time(idziqrgraph'),dataz(idziqrgraph),'c*');
        ylabel('U[mm]');
        xlabel('Year')
        legend('Original','3IQR');
        hold off;
        
        percentiqr = length(idxiqr)/length(datax);
        percent = [percent;percentiqr];
        
        graph = strcat(cd,'\TSprocessing\OutlierDetection\IQR\graph','\',A(ss,1).name);
        graph(end-5:end) = [];
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
   
    end
    fileoutput = strcat(cd,'\TSprocessing\OutlierDetection\IQR\percentage of OD.txt');
    fid = fopen(fileoutput,'wt');
    fprintf(fid,'The crition is %dIQR\n',mult);
    fprintf(fid,'%s\t%s\n','PointName ','%');
    for i = 1:length(pn)
        fprintf(fid,'%s\t',mat2str(pn{i}));
        fprintf(fid,'%6.3f\t\n',percent(i)*100);
    end
    fclose(fid);
    open(fileoutput);
end