function   namelist = CME_StackFlitering(filepath)
%% stack flitering   
    current = filepath;
    A=dir(current);
    for ss=3:length(A)
        folder=strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        
        [Gcd,num,x,y,z,Sx,Sy,Sz,Rxy,Rxz,Ryz,lon,lati] = textread(folder, '%s%f%f%f%f%f%f%f%f%f%f%f%f', 'delimiter','\t');
        fclose(fid);
        xx(:,ss-2)=x;
        yy(:,ss-2)=y;
        zz(:,ss-2)=z;
        SxSx(:,ss-2)=Sx;
        SySy(:,ss-2)=Sy;
        SzSz(:,ss-2)=Sz;
        RxyRxy(:,ss-2)=Rxy;
        RxzRxz(:,ss-2)=Rxz;
        RyzRyz(:,ss-2)=Ryz;
        longlong(:,ss-2)=lon;
        latilati(:,ss-2)=lati;
        GcdGcd(:,ss-2)=Gcd;
        clearvars -except num current current1 new_folder A AA xx yy zz SxSx SySy SzSz RxyRxy RxzRxz RyzRyz x1 y1 z1 GcdGcd site longlong latilati;
    end
%     namelist = '';
    for ss = 3:length(A)
        namelist{ss-2} = A(ss,1).name(1:4);
    end
    
%     for ss=3:length(A)
%         namelist = [namelist;A(ss,1).name(1:4)];
%     end
    
    [m,n]=size(xx);
    CME1x=0;
    CME1y=0;
    CME1z=0;
    % caculate corr
    for i=1:n
        for j=1:n
            rx=corr([xx(:,i),xx(:,j)]);
            rxx(i,j)=rx(1,2);
            ry=corr([yy(:,i),yy(:,j)]);
            ryy(i,j)=ry(1,2);
            rz=corr([zz(:,i),zz(:,j)]);
            rzz(i,j)=rz(1,2);
        end
    end
% Raw data RMS
    for i=1:n
        RMS0x(i,1)=sqrt(sum(xx(:,i).^2)/length(num));
        RMS0y(i,1)=sqrt(sum(yy(:,i).^2)/length(num));
        RMS0z(i,1)=sqrt(sum(zz(:,i).^2)/length(num));
    end
        RMS = [RMS0x RMS0y RMS0z];
        dname = [cd '\CME\'];
        fn = 'RMS.txt';
        save ([dname fn],'RMS','-ascii')
%% 1.stack flitering
    for i=1:n
        CME1x=CME1x+xx(:,i)/n;
        CME1y=CME1y+yy(:,i)/n;
        CME1z=CME1z+zz(:,i)/n;
    end
    for i=1:n
        pointname=A(i+2,1).name(1:4);
        lvx1(:,i)=xx(:,i)-CME1x;
        lvy1(:,i)=yy(:,i)-CME1y;
        lvz1(:,i)=zz(:,i)-CME1z;
        
        figure
        subplot(3,2,1)
        plot(num,xx(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvx1(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('East');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,3)
        plot(num,yy(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvy1(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('North');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,5)
        plot(num,zz(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvz1(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('Up')
        ylabel('Displacement/mm');
        xlabel('Year')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,2)
        plot(num,CME1x,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('East');
        ylabel('Displacement/mm');
        title('CME-East')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,4)
        plot(num,CME1y,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('North');
        ylabel('Displacement/mm');
        title('CME-North')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,6)
        plot(num,CME1z,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('Up');
        ylabel('Displacement/mm');
        xlabel('Year')
        title('CME-Up')
        xlim([num(1) num(end)]);
        hold off
        
        dname = cd;
        dname = [dname '\CME\Stack_Flitering\graph\'];
        f = strcat( pointname ,'.fig' );
        saveas(gcf,[dname f])
%         ff = strcat( pointname ,'.emf' );
%         print(gcf,'-dmeta',[dname ff]) %emf��ʽ
%         fff = strcat( pointname ,'.jpg' );
%         print(gcf,'-djpeg   ',[dname fff]) %jpg��ʽ
%% to *.mom
        fid1E = strcat(cd,'\CME\Stack_Flitering\.mom\',A(i+2,1).name(1:4),'_0.mom');
        txt1E = fopen(fid1E, 'w');

        fid1N = strcat(cd,'\CME\Stack_Flitering\.mom\',A(i+2,1).name(1:4),'_1.mom');
        txt1N = fopen(fid1N, 'w');

        fid1U = strcat(cd,'\CME\Stack_Flitering\.mom\',A(i+2,1).name(1:4),'_2.mom');
        txt1U = fopen(fid1U, 'w');

        fprintf(txt1E,'%s\n','# sampling period 1');
        fprintf(txt1N,'%s\n','# sampling period 1');
        fprintf(txt1U,'%s\n','# sampling period 1');
        for j = 1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt1E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt1E,'%8.6f\t\n',lvx1(j,i));
            else
                fprintf(txt1E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
                fprintf(txt1E,'%8.6f\t\n',lvx1(j,i));
            end
        end
        for j = 1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt1N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt1N,'%8.6f\t\n',lvy1(j,i));
            else
              fprintf(txt1N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt1N,'%8.6f\t\n',lvy1(j,i));
            end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt1U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt1U,'%8.6f\t\n',lvz1(j,i));
            else
              fprintf(txt1U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt1U,'%8.6f\t\n',lvz1(j,i));
            end
        end
        
        fid1 = strcat(cd,'\CME\Stack_Flitering\',A(i+2,1).name);
        txt1 = fopen(fid1, 'w');
        for j=1:length(num)
            fprintf(txt1,'%8.8f\t',num(j,1));
            fprintf(txt1,'%8.2f\t',lvx1(j,i));
            fprintf(txt1,'%8.2f\t',lvy1(j,i));
            fprintf(txt1,'%8.2f\t',SxSx(j,i));
            fprintf(txt1,'%8.2f\t',SySy(j,i));
            fprintf(txt1,'%8.4f\t',RxyRxy(j,i));
            fprintf(txt1,'%8.2f\t',lvz1(j,i));
            fprintf(txt1,'%8.2f\t',SzSz(j,i));
            fprintf(txt1,'%8.4f\t',RxzRxz(j,i));
            fprintf(txt1,'%8.4f\t',RyzRyz(j,i));
            fprintf(txt1,'%s\t',char(GcdGcd{j,1}));
            fprintf(txt1,'%8.4f\t',longlong(j,i));
            fprintf(txt1,'%8.4f\t\n',latilati(j,i));
        end
        RMS1x(i,1)=sqrt(sum(lvx1(:,i).^2)/length(num));
        RMS1y(i,1)=sqrt(sum(lvy1(:,i).^2)/length(num));
        RMS1z(i,1)=sqrt(sum(lvz1(:,i).^2)/length(num));
    end
    RMS1 = [RMS1x RMS1y RMS1z];
    dname = [cd '\CME\Stack_Flitering'];
    fn = '\RMS1.txt';
    save ([dname fn],'RMS1','-ascii')
    fclose('all');
end
