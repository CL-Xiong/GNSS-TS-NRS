function Plot_GPSTS(directions)
% choose_text{1}='Which  painting is you want to draw,three directions or one direction? ';
% choose_text{2}='Please choose';
% Choose =  (questdlg(choose_text, 'Choice', 'Three directions','One direction','Three direction'));
% switch Choose
%     case 'Three directions'
%         Plot_GPSTS_3_Direction
%     case  'One direction'
%         Plot_GPSTS_1_Direction
% end
switch directions
    case 'one direction'
         Plot_GPSTS_1_Direction
    case 'three directions'
         Plot_GPSTS_3_Direction
    otherwise
        error('error input arguments!')
end
end

