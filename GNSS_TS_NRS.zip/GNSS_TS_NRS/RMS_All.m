function RMS_All(directions)
% one direction
% three direction
if nargin ~= 1
    error('error input arrgunment!')
end
switch directions
    case 'one direction'
        step = 1;
    case 'three directions'
        step = 3;
end
filepath = uigetdir(strcat(cd,'\example\NoiseReduction'),'Please choose a folder'); 
current = filepath;
A = dir(current);
k = 0; % site number
if  step == 1
    for ss = 3:step:length(A)
        folder = strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        data =  textscan(fid,' %f %f','headerlines',1);
        E = data{2};
        fclose(fid);
        RMS0e = sqrt(sum(E.^2)/length(E));
        RMS0(ss-2) = [RMS0e];
        k = k+1;
        siteName{k} = A(ss,1).name(1:4) ;
    end
    figure
    bar(RMS0,'g','EdgeColor',[1 0.5 0.5])
%     bar(RMS0)
    set(gca,'FontSize',10,'FontName', 'times new roman');
    xlabel('Site')
    ylabel('RMS/mm')
    xlim([0 k+1]);
    graph = strcat(cd,'\TSexpression\RMS\');
    g = get(gcf,'Number');
    graph = strcat(graph, num2str(g) ,'.fig');
    saveas(gcf,graph)
end
 %%
if step == 3
    for ss = 3:step:length(A)
        folder = strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        data =  textscan(fid,' %f %f','headerlines',1);
        E = data{2};
        fclose(fid);
        folder =strcat(current,'\',A(ss+1,1).name);
        fid = fopen(folder);
        data = textscan(fid, '%f%f','headerlines',1);
        N = data{2};
        fclose(fid);
        folder=strcat(current,'\',A(ss+2,1).name);
        fid = fopen(folder);
        data = textscan(fid, '%f%f','headerlines',1);
        U = data{2};
        fclose(fid);
        RMS0e = sqrt(sum(E.^2)/length(E));
        RMS0n = sqrt(sum(N.^2)/length(N));
        RMS0u = sqrt(sum(U.^2)/length(U));
        RMS0(ss/3,:) = [RMS0e RMS0n RMS0u];
        k = k+1;
        siteName{k} = A(ss,1).name(1:4) ;
    end

    for j = 1:3
        figure
%         bar(RMS0(:,j),'g','EdgeColor',[1 0.5 0.5]);
        bar(RMS0(:,j),'c');
        set(gca,'FontSize',10,'FontName', 'times new roman');
        set(gca,'XTickLabel',siteName)
        xlabel('Site')
        xlim([0 k+1]);
        ylabel('RMS/mm') 
        if j == 1
            title('E')
        end
        if j == 2
            title('N')
        end
        if j == 3
            title('U')
        end
%         legend('before','after') 
        graph = strcat(cd,'\TSexpression\RMS\');
        g = get(gcf,'Number');
        graph = strcat(graph, num2str(g) ,'.fig');
        saveas(gcf,graph)
    end
end 

dname = [cd '\TSexpression\RMS'];
fn = '\RMS0.txt';
save ([dname fn],'RMS0','-ascii')
open([dname fn]);
end