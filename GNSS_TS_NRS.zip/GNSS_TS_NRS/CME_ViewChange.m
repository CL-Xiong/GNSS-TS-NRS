function CME_ViewChange(percentage,CME_method,namelist)
% create the legend
for i = 1: length(CME_method)
    if  CME_method(i) == 1
        leg{i} = 'Stacking Filtering';
    elseif CME_method(i) == 2
        leg{i} = 'Weightd Stacking';
    elseif CME_method(i) == 3
        leg{i} = 'Correlation Weightd Stacking';
    elseif CME_method(i) == 4
        leg{i} = 'Distance Weightd Stacking';
    elseif CME_method(i) == 5
        leg{i} = 'PCA';
    end
end
%%
[m n] = size(percentage);
figure
for i = 1:3:n
    
    plot(100*percentage(:,i),'-ro')
    hold on 
    set(gca, 'FontName', 'Times New Roman','FontSize',10);
    set(gca,'XTickLabel',namelist)
    xlabel('Site')
    ylabel('%')
    title('East')
end
legend(leg)
str = 'Change-E';
dname = [cd '\CME\'];
f = [str '.fig'];
saveas(gcf,[dname f])
%%
figure
for i = 2:3:n
    plot(100*percentage(:,i),'-go')
    hold on 
    set(gca, 'FontName', 'Times New Roman','FontSize',10);
    set(gca,'XTickLabel',namelist)
    xlabel('Site')
    ylabel('%')
    title('North')
end
legend(leg)
str = 'Change-N';
dname = [cd '\CME\'];
f = [str '.fig'];
saveas(gcf,[dname f])
%% 
figure
for i = 3:3:n
    plot(100*percentage(:,i),'-bo')
    hold on 
    set(gca, 'FontName', 'Times New Roman','FontSize',10);
    set(gca,'XTickLabel',namelist)
    xlabel('Site')
    ylabel('%')
    title('Up')
end
legend(leg)
str = 'Change-U';
dname = [cd '\CME\'];
f = [str '.fig'];
saveas(gcf,[dname f])
hold off
end