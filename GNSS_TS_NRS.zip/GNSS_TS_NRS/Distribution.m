function Distribution(choice)
%% 
% choice = 'both';
% choice = 'alpha';
% choice = 'both';
TextX = 0;
TextY = 0.05;% TextX��TextY means the location of text in subplot
switch choice
    case 'norm'
        Norm(TextX,TextY)
    case 'alpha'
        Alpha(TextX,TextY)
    case 'both'
        NormandAlpha(TextX,TextY)
end

function Norm(TextX,TextY)
    current = uigetdir(strcat(cd,'\example\Distribution'),'Please choose a folder'); 
    A = dir(current);
    set(0,'defaultfigurecolor','w')
    for k = 3:1:length(A)
        file1 = strcat(current,'\',A(k,1).name);
        fid1 = fopen(file1);
        data = textscan(fid1,'%f %f %f','HeaderLines',2);
        Raw_TS = data{2};
        EstimatedModel = data{3};
        resi = Raw_TS-EstimatedModel; % residual
        fclose(fid1);
        % fit distribution with normal 
        x_values = linspace(min(resi),max(resi),200);
        pd_norm =  fitdist(resi,'Normal');
        % caculate pdf and cdf of different distribution
        pdf_norm = pdf(pd_norm,x_values);
        cdf_norm = cdf(pd_norm,x_values);
        %%
        figure
        subplot(2,1,1)
        [norm1,norm2] = histnorm(resi, 200, 'plot');
        histnorm(resi, 200, 'plot')
        hold on

        corr_norm = corrcoef(pdf_norm,norm1);
        norm_corr_2 = sprintf('%.2f',corr_norm(1,2));
        plot(x_values,pdf_norm,'r','linewidth',2)
        str = ['Corr = ',norm_corr_2];
        text(TextX,TextY,str,'FontName', 'times new roman'); 
%         str2 = 'Normal distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        box off
        three = legend('Data','Fit Normal pdf','Location','NorthEast');
        set(three,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('a) Normal distribution')
        hold off
        %%
        subplot(2,1,2)
        cdfplot2(resi)
        set(gca,'FontSize',10,'FontName', 'times new roman');
        hold on
        plot(x_values,cdf_norm,'r','linewidth',1)
        
        box off
        four = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(four,'edgecolor','white')
%         str2 = 'Normal distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        xlabel('b) CDF of Normal distribution')
        hold off
        savefig = strcat('TSexpression\Distribution\',A(k,1).name);
        savefig(end-3:end) = [];
        savefig = [savefig '.fig'];
        saveas(gcf,savefig)
        %% adtest for normal
        leve = 0.05;
        filepath = 'TSexpression\Distribution\';
        [h1,para(1),stat(1),cv(1)] = adtest(resi,'distribution',pd_norm,'Alpha',leve); % adtest: norm
        Adtestpath = [filepath 'normal-adtest.txt'];
        fid = fopen(Adtestpath,'a+');
        fprintf(fid,'%d\t',double(h1));
        fprintf(fid,'%d\t',para(1));
        fprintf(fid,'%d\t',stat(1));
        fprintf(fid,'%d\t',cv(1)); 
        fprintf(fid,'%d\n',corr_norm(1,2)); 
        fclose(fid);
    end
end
function Alpha(TextX,TextY)
    current = uigetdir(strcat(cd,'\example\Distribution'),'Please choose a folder'); 
    A = dir(current);
    set(0,'defaultfigurecolor','w')
    for k = 3:1:length(A)
        file1 = strcat(current,'\',A(k,1).name);
        fid1 = fopen(file1);
        data = textscan(fid1,'%f %f %f','HeaderLines',2);
        Raw_TS = data{2};
        EstimatedModel = data{3};
        resi = Raw_TS-EstimatedModel; % residual
        fclose(fid1);
        % fit distribution with normal and stable
        x_values = linspace(min(resi),max(resi),200);
        pd_stable = fitdist(resi,'Stable');
        % caculate pdf and cdf of different distribution
        pdf_stable = pdf(pd_stable,x_values);
        cdf_stable = cdf(pd_stable,x_values);
        % plot data with fit parameters
        figure
        clf;%clear fig
        %%
        subplot(2,1,1)
        [alpha1 alpha2] = histnorm(resi, 200, 'plot');
        hold on
        %%
        plot(x_values,pdf_stable,'r-','linewidth',2);
        corr_alpha = corrcoef(pdf_stable,alpha1);
        alpha_corr_2 = sprintf('%.2f',corr_alpha(1,2));
        hold off
        str = {['\alpha_0 = ',num2str(pd_stable.alpha),'  \beta_0 = ',num2str(pd_stable.beta)],['\gamma_0 = ',num2str(pd_stable.gam),...
            '  \delta_0 = ',num2str(pd_stable.delta)], ['Corr = ',alpha_corr_2]};        
        text(TextX,TextY,str,'FontName', 'times new roman');
%         str2 = 'Alpha-stable distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        set(0,'defaultfigurecolor','w')
        xlabel('a) Alpha-stable distribution')
        h = legend('Data','Fit stable pdf','Location','NorthEast');
        set(h,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        box off
        hold off
       %% 
        subplot(2,1,2)
        cdfplot2(resi)
        hold on;
        plot(x_values,cdf_stable,'r-','linewidth',1)
        box off
%         str2 = 'Alpha-stable distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('b) CDF of Alpha-stable distribution')
        two = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(two,'edgecolor','white')
        hold off
        
        savefig = strcat('TSexpression\Distribution\',A(k,1).name);
        savefig(end-3:end) = [];
        savefig = [savefig '.fig'];
        saveas(gcf,savefig)
        %% adtest for alpha stable
        leve = 0.05;
        filepath = 'TSexpression\Distribution\';
        [h1,para(1),stat(1),cv(1)] = adtest(resi,'distribution',pd_stable,'Alpha',leve);% adtest: stable
        Adtestpath = [filepath 'alpha-adtest.txt'];
        fid = fopen(Adtestpath,'a+');
        fprintf(fid,'%d\t',double(h1));
        fprintf(fid,'%d\t',para(1));
        fprintf(fid,'%d\t',stat(1));
        fprintf(fid,'%d\t',cv(1));
        fprintf(fid,'%d\n',corr_alpha(1,2));
        fclose(fid);
    end
end

function NormandAlpha(TextX,TextY)
    current = uigetdir(strcat(cd,'\example\Distribution'),'Please choose a folder'); 
    A = dir(current);
    set(0,'defaultfigurecolor','w')
    for k = 3:1:length(A)
        file1 = strcat(current,'\',A(k,1).name);
        fid1 = fopen(file1);
        data = textscan(fid1,'%f %f %f','HeaderLines',2);
        Raw_TS = data{2};
        EstimatedModel = data{3};
        resi = Raw_TS-EstimatedModel; % residual
        fclose(fid1);
        
        x_values = linspace(min(resi),max(resi),200);
        pd_stable = fitdist(resi,'Stable');
        pd_norm =  fitdist(resi,'Normal');
        % caculate pdf and cdf of different distribution
        pdf_stable = pdf(pd_stable,x_values);
        pdf_norm = pdf(pd_norm,x_values);
        cdf_stable = cdf(pd_stable,x_values);
        cdf_norm = cdf(pd_norm,x_values);
        
        % plot data with fit parameters
        figure
        set(gcf,'position',[30,30,893,682]);
        clf;%clear fig
        % %     set(gcf,'position',[centerX,centerY,width,height])
       %% PDF for alpha stable
        subplot(2,2,1)
        histnorm(resi, 101, 'plot'); %the normalized histgram 
        [alpha1 alpha2] = histnorm(resi, 200, 'plot');
        hold on
        plot(x_values,pdf_stable,'r-','linewidth',2);
        corr_alpha = corrcoef(pdf_stable,alpha1);
        alpha_corr_2 = sprintf('%.2f',corr_alpha(1,2));
        hold off
        str = {['\alpha_0 = ',num2str(pd_stable.alpha),'  \beta_0 = ',num2str(pd_stable.beta)],['\gamma_0 = ',num2str(pd_stable.gam),...
            '  \delta_0 = ',num2str(pd_stable.delta)], ['Corr = ',alpha_corr_2]};               text(TextX,TextY,str,'FontName', 'times new roman'); 
%         str2 = 'Alpha-stable distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        set(0,'defaultfigurecolor','w')
        xlabel('a) Alpha-stable distribution')
        h = legend('Data','Fit stable pdf','Location','NorthEast');
        set(h,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        box off
        hold off
       %% CDF for alpha stable
        subplot(2,2,2)
        cdfplot2(resi)
        hold on;
        plot(x_values,cdf_stable,'r-','linewidth',1)
        box off
%         str2 = 'Alpha-stable distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman');
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('b) CDF of Alpha-stable distribution')
        two = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(two,'edgecolor','white')
        hold off
        %% PDF for normal 
        subplot(2,2,3)
        [norm1,norm2] = histnorm(resi, 200, 'plot');
        hold on
        corr_norm = corrcoef(pdf_norm,norm1);
        norm_corr_2 = sprintf('%.2f',corr_norm(1,2));
        plot(x_values,pdf_norm,'r','linewidth',2)
        str = ['Corr = ',norm_corr_2];
        text(TextX,TextY,str,'FontName', 'times new roman');
%         str2 = 'Normal distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        box off
        three = legend('Data','Fit Normal pdf','Location','NorthEast');
        set(three,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('c) Normal distribution')
        hold off
        %% CDF for normal 
        subplot(2,2,4)
        cdfplot2(resi)
        set(gca,'FontSize',10,'FontName', 'times new roman');
        hold on
        plot(x_values,cdf_norm,'r','linewidth',1)
        box off
        four = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(four,'edgecolor','white')
%         str2 = 'Normal distribution';
%         text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        xlabel('d) CDF of Normal distribution')
        hold off
        %%
        savefig = strcat('TSexpression\Distribution\',A(k,1).name);
        savefig(end-3:end) = [];
        savefig = [savefig '.fig'];
        saveas(gcf,savefig)
        %% adtest for normal and alpha stable
        leve = 0.05;
        filepath = 'TSexpression\Distribution\';
        [h1,para(1),stat(1),cv(1)] = adtest(resi,'distribution',pd_norm,'Alpha',leve); % adtest: norm
        [h2,para(2),stat(2),cv(2)] = adtest(resi,'distribution',pd_stable,'Alpha',leve);% adtest: stable
        % stable
        Adtestpath = [filepath 'normal-adtest.txt'];
        fid = fopen(Adtestpath,'a+');
        fprintf(fid,'%d\t',double(h1));
        fprintf(fid,'%d\t',para(1));
        fprintf(fid,'%d\t',stat(1));
        fprintf(fid,'%d\t',cv(1)); 
        fprintf(fid,'%d\n',corr_norm(1,2)); 
        fclose(fid);
        % alpha
        Adtestpath2 = [filepath 'alpha-adtest.txt'];
        fid2 = fopen(Adtestpath2,'a+');
        fprintf(fid2,'%d\t',double(h2));
        fprintf(fid2,'%d\t',para(2));
        fprintf(fid2,'%d\t',stat(2));
        fprintf(fid2,'%d\t',cv(2));
        fprintf(fid2,'%d\n',corr_alpha(1,2));
        fclose(fid2);
        fclose('all');
    end
end
end