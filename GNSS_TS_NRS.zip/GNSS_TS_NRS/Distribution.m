function Distribution(choice)
%% 
% choice = 'both';
% choice = 'alpha';
% choice = 'both';
TextX = 0;
TextY = 0.05;% TextX��TextY means the location of text in subplot
switch choice
    case 'norm'
        Norm(TextX,TextY)
    case 'alpha'
        Alpha(TextX,TextY)
    case 'both'
        NormandAlpha(TextX,TextY)
end

function Norm(TextX,TextY)
    current = uigetdir(strcat(cd,'\example\Distribution'),'Please choose a folder'); 
    A = dir(current);
    set(0,'defaultfigurecolor','w')
    for k = 3:1:length(A)
        file1 = strcat(current,'\',A(k,1).name);
        fid1 = fopen(file1);
        data = textscan(fid1,'%f %f %f','HeaderLines',2);
        Raw_TS = data{2};
        EstimatedModel = data{3};
        resi = Raw_TS-EstimatedModel; % residual
        fclose(fid1);
        figure
        subplot(2,1,1)
        [norm1,norm2] = histnorm(resi, 200, 'plot');
        histnorm(resi, 200, 'plot')
        hold on
        vec = [min(resi):(max(resi)-min(resi))./199:max(resi)];% vec for the pdf
        norm_pdf = 1./sqrt(2.*pi.*var(resi)).*exp(-0.5./var(resi).*(vec-mean(resi)).^2); % normpdf

        norm_corr = corrcoef(norm_pdf,norm1);
        norm_corr_2 = sprintf('%.2f',norm_corr(1,2));
        plot(vec,norm_pdf,'r','linewidth',2)
        str = ['Corr = ',norm_corr_2];
        text(TextX,TextY,str,'FontName', 'times new roman'); 
        str2 = 'Normal distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        box off
        three = legend('Data','Fit Normal pdf','Location','NorthEast');
        set(three,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('a) Normal distribution')
        hold off
        %%
        subplot(2,1,2)
        cdfplot2(resi)
        set(gca,'FontSize',10,'FontName', 'times new roman');
        hold on
        x = linspace(min(resi),max(resi),length(resi));
        mu = mean(resi);
        sigma = std(resi,0,1);
        norm_cdf = normcdf(x,mu,sigma);
        plot(x,norm_cdf,'r','linewidth',1)
        box off
        four = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(four,'edgecolor','white')
        str2 = 'Normal distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        xlabel('b) CDF of Normal distribution')
        hold off
        savefig = strcat('TSexpression\Distribution\',A(k,1).name);
        savefig(end-3:end) = [];
        savefig = [savefig '.fig'];
        saveas(gcf,savefig)
    end
end
function Alpha(TextX,TextY)
    current = uigetdir(strcat(cd,'\example\Distribution'),'Please choose a folder'); 
    A = dir(current);
    set(0,'defaultfigurecolor','w')
    for k = 3:1:length(A)
        file1 = strcat(current,'\',A(k,1).name);
        fid1 = fopen(file1);
        data = textscan(fid1,'%f %f %f','HeaderLines',2);
        Raw_TS = data{2};
        EstimatedModel = data{3};
        resi = Raw_TS-EstimatedModel; % residual
        fclose(fid1);

        % estimate parameters
        p = stblfit(resi,'ecf',statset('Display','iter'));
        % plot data with fit parameters
        figure
        clf;%clear fig
        % %     set(gcf,'position',[centerX,centerY,width,height])
        %%
        subplot(2,1,1)
        histnorm(resi, 101, 'plot'); %the normalized histgram 
        [alpha1 alpha2] = histnorm(resi, 200, 'plot');
        hold on
        %%
        x = linspace(min(resi),max(resi),200);
        alpha_pdf = stblpdf(x,p(1),p(2),p(3),p(4),'quick');
        plot(x,alpha_pdf,'r-','linewidth',2);
        alpha_corr = corrcoef(alpha_pdf,alpha1);
        alpha_corr_2 = sprintf('%.2f',alpha_corr(1,2));
        hold off
        str = {['\alpha_0 = ',num2str(p(1)),'  \beta_0 = ',num2str(p(2))],['\gamma_0 = ',num2str(p(3)),'  \delta_0 = ',num2str(p(4))], ['Corr = ',alpha_corr_2]};
        text(TextX,TextY,str,'FontName', 'times new roman');
        str2 = 'Alpha-stable distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        set(0,'defaultfigurecolor','w')
        xlabel('a) Alpha-stable distribution')
        h = legend('Data','Fit stable pdf','Location','NorthEast');
        set(h,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        box off
        hold off
       %% 
        subplot(2,1,2)
        cdfplot2(resi)
        cmin = min(resi);
        cmax = max(resi);
        x = cmin:.1:cmax;
        estCDF = stblcdf(x,p(1),p(2),p(3),p(4));
        hold on;
        plot(x,estCDF,'r-','linewidth',1)
        box off
        str2 = 'Alpha-stable distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('b) CDF of Alpha-stable distribution')
        two = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(two,'edgecolor','white')
        hold off
    end
    savefig = strcat('TSexpression\Distribution\',A(k,1).name);
    savefig(end-3:end) = [];
    savefig = [savefig '.fig'];
    saveas(gcf,savefig)
end

function NormandAlpha(TextX,TextY)
    current = uigetdir(strcat(cd,'\example\Distribution'),'Please choose a folder'); 
    A = dir(current);
    set(0,'defaultfigurecolor','w')
    for k = 3:1:length(A)
        file1 = strcat(current,'\',A(k,1).name);
        fid1 = fopen(file1);
        data = textscan(fid1,'%f %f %f','HeaderLines',2);
        Raw_TS = data{2};
        EstimatedModel = data{3};
        resi = Raw_TS-EstimatedModel; % residual
        fclose(fid1);

        % estimate parameters
        p = stblfit(resi,'ecf',statset('Display','iter'));
        % plot data with fit parameters
        figure
        set(gcf,'position',[30,30,893,682]);
        clf;%clear fig
        % %     set(gcf,'position',[centerX,centerY,width,height])
        %%
        subplot(2,2,1)
        histnorm(resi, 101, 'plot'); %the normalized histgram 
        [alpha1 alpha2] = histnorm(resi, 200, 'plot');
        hold on
        %%
        x = linspace(min(resi),max(resi),200);
        alpha_pdf = stblpdf(x,p(1),p(2),p(3),p(4),'quick');
        plot(x,alpha_pdf,'r-','linewidth',2);
        alpha_corr = corrcoef(alpha_pdf,alpha1);
        alpha_corr_2 = sprintf('%.2f',alpha_corr(1,2));
        hold off
        str = {['\alpha_0 = ',num2str(p(1)),'  \beta_0 = ',num2str(p(2))],['\gamma_0 = ',num2str(p(3)),'  \delta_0 = ',num2str(p(4))], ['Corr = ',alpha_corr_2]};
        text(TextX,TextY,str,'FontName', 'times new roman'); 
        str2 = 'Alpha-stable distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        set(0,'defaultfigurecolor','w')
        xlabel('a) Alpha-stable distribution')
        h = legend('Data','Fit stable pdf','Location','NorthEast');
        set(h,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        box off
        hold off
       %% 
        subplot(2,2,2)
        cdfplot2(resi)
        cmin = min(resi);
        cmax = max(resi);
        x = cmin:.1:cmax;
        estCDF = stblcdf(x,p(1),p(2),p(3),p(4));
        hold on;
        plot(x,estCDF,'r-','linewidth',1)
        box off
        str2 = 'Alpha-stable distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman');
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('b) CDF of Alpha-stable distribution')
        two = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(two,'edgecolor','white')
        hold off
        %%
        subplot(2,2,3)
        [norm1,norm2] = histnorm(resi, 200, 'plot');
        histnorm(resi, 200, 'plot')
        hold on
        vec = [min(resi):(max(resi)-min(resi))./199:max(resi)];% vec for the pdf
        norm_pdf = 1./sqrt(2.*pi.*var(resi)).*exp(-0.5./var(resi).*(vec-mean(resi)).^2); % normpdf

        norm_corr = corrcoef(norm_pdf,norm1);
        norm_corr_2 = sprintf('%.2f',norm_corr(1,2));
        plot(vec,norm_pdf,'r','linewidth',2)
        str = ['Corr = ',norm_corr_2];
        text(TextX,TextY,str,'FontName', 'times new roman');
        str2 = 'Normal distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        box off
        three = legend('Data','Fit Normal pdf','Location','NorthEast');
        set(three,'edgecolor','white')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlabel('c) Normal distribution')
        hold off
        %%
        subplot(2,2,4)
        cdfplot2(resi)
        set(gca,'FontSize',10,'FontName', 'times new roman');
        hold on
        x = linspace(min(resi),max(resi),length(resi));
        mu = mean(resi);
        sigma = std(resi,0,1);
        norm_cdf = normcdf(x,mu,sigma);
        plot(x,norm_cdf,'r','linewidth',1)
        box off
        four = legend('Empirical CDF','Estimated CDF','Location','SouthEast');
        set(four,'edgecolor','white')
        str2 = 'Normal distribution';
        text(TextX+0.001,TextY+0.001,str2,'FontName', 'times new roman'); 
        xlabel('d) CDF of Normal distribution')
        hold off
        %%
        savefig = strcat('TSexpression\Distribution\',A(k,1).name);
        savefig(end-3:end) = [];
        savefig = [savefig '.fig'];
        saveas(gcf,savefig)
    end
end
    
end