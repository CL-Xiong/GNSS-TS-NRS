
function c = fftconv(a,b,force)

na = length(a);
nb = length(b);

if force,
 n = 2^(fix(log2(na+nb))+1);
else
 n=na+nb;
end;
A = fft(a,n);
B = fft(b,n);

c = ifft(A.*B,n);
c = real(c(1:na+nb-1));
