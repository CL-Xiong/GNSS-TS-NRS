function Plot_Simulated
    GlobalConstant 
    if strcmp( Simulated_Choice , 'PerFun')
        MJD_Time = 1:1:Data_Length;
        MJD_Time = MJD_Time';
        figure
        subplot(2,2,1)
        plot(1:Data_Length,y1)
        xlim([0,Data_Length])
        title('y1')
        xlabel('Time')
        ylabel('Amplitude/mm')

        subplot(2,2,2)
        plot(1:Data_Length,y2)
        xlim([0,Data_Length])
        title('y2')
        xlabel('Time')
        ylabel('Amplitude/mm')

        subplot(2,2,3)
        plot(1:Data_Length,y3)
        xlim([0,Data_Length])
        title('y3')
        xlabel('Time')
        ylabel('Amplitude/mm')

        if ~isempty(Noise_Index)
            subplot(2,2,4)
            plot(1:Data_Length,Noise)
            xlim([0,Data_Length])
            title('Noise')
            xlabel('Time')
            ylabel('Amplitude/mm')
        end
        dname = cd;
        f = '\NoiseReduction\Fig_Simulated.fig';
        saveas(gcf,[dname f])
    end
    
    if strcmp(Simulated_Choice , 'SeaSig')
        figure
        subplot(2,1,1)
        plot(MJD_Time,Simulated_Data)
        title('Rawdata')
        xlabel('Time')
        ylabel('Amplitude/mm')

        if ~isempty(Noise_Index)
            subplot(2,1,2)
            plot(MJD_Time,Noise)
            title('Noise')
            xlabel('Time/')
            ylabel('Amplitude/mm')
        end
        dname = cd;
        f = '\NoiseReduction\Fig_Simulated.fig';
        saveas(gcf,[dname f])
    end

end