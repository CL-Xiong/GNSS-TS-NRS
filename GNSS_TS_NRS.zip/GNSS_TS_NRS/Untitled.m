figure
T = boxchart(resi,'MarkerStyle','x','BoxFaceColor',[0 0 1])
figure
boxplot(resi)
legend(T)

b = boxchart(resi);
ylabel('Number of Customers')


 hReg2(end+1) = plot(y,meanX,'+','linewidth',linewidth,'color',meanColor,'markersize',10);
 
 boxColor = [0.0005    0.3593    0.7380];
wisColor = [0 0 0]+.3;
meanColor = [0.9684    0.2799    0.0723];

%% bplot 247行