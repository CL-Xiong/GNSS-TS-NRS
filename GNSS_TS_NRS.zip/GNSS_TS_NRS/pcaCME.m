function [cxi,v,d]=pcaCME(X)
[m,n]=size(X);

B=zeros(n,n);

for i=1:n %B(i,j)
    for j=1:n
        if i==j
            Mi = find(X(:,i)~=0);
            mi = length(Mi);
            temp=0;
            for k=1:mi
                temp=temp+X(Mi(k),i)^2;
            end
            if mi>1
                B(i,i)=temp/(mi-1);
            else
                B(i,i)=temp;
            end
        else
            Mi  = find(X(:,i)~=0);
            Mj  = find(X(:,j)~=0);
            Mij = intersect(Mi,Mj);
            if isempty(Mij) 
                continue;
            end
            mij = length(Mij);
            temp=0;
            for k=1:mij
                temp=temp+X(Mij(k),i)*X(Mij(k),j);
            end
            if mij>1
                B(i,j)=temp/(mij-1);
            else
                B(i,j)=temp;
            end
        end
    end
end

[v,d]=eigenshuffle(B);
cY=cell(m,1);
for i=1:m
    for j=1:n
        I=find(X(i,:)~=0);
        if(~isempty(I))
            temp=0;
            for k=1:length(I)
                temp=temp+(X(i,I(k))*v(I(k),j));
            end
        else
            temp=0;
        end
        y(j,1)=temp;
    end
    cY{i,1}=y;
end

cA=cell(m,1);
for i=1:m
    for j=1:n
        for k=1:n
            I=find(X(i,:)==0);
            if(~isempty(I))
                temp=0;
                for l=1:length(I)
                    temp=temp+v(I(l),j)*v(I(l),k);
                end
            else
                temp=0;
            end
            if k==j
                a(j,k)=1-temp;
            else
                a(j,k)=-temp;
            end
        end
    end
    cA{i,1}=a;
end

for i=1:m
    A=cA{i,1};
    Y=cY{i,1};
    xi=A'*pinv(A'*A)*Y;
    if i==1
        cxi=xi';
    else
        cxi=[cxi;xi'];
    end
end




