function Plot_Method1(RawData,data,Pk,leng)
    GlobalConstant
    %%
    if  Simulated_Index == 1
        time = MJD_Time;
    else
        time = MJD2Day(MJD_Time);
    end
    %%
    if Choose_Index == 1
        figure 
        x = 1:leng;
        plot(x ,Pk,'--o')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        title('Correlation Coefficient Curve')
        xlabel('IMF Serial Number')
        ylabel(' Correlation Coefficient')
        set(gca,'FontSize',8)
        dname = cd;
        dname = [dname '\NoiseReduction\Method1'];
        f = '\Fig_Method1_CORR.fig';
        saveas(gcf,[dname f])

        figure
        hold on
        plot( time ,RawData)
        plot( time ,data,'color',[1 0 0])
        set(gca,'FontSize',10,'FontName', 'times new roman');
        title('RawData vs Noise Reduction Signals')
        xlabel('Time')
        ylabel('Amplitude/mm')
        xlim([time(1),time(end)])
        legend('RawData','Method1 ','location','best')
        dname = cd;
        dname = [dname '\NoiseReduction\Method1'];
        f = '\Fig_Method1_Data.fig';
        saveas(gcf,[dname f])
    end
%%
    if Choose_Index == 3
        figure
        hold on
        x = 1:leng;
        plot(x ,Pk(1,:),'-o','color',[0 1 0])
        plot(x ,Pk(2,:),'-r+','color',[1 0 1])
        plot(x ,Pk(3,:),'-*','color',[0 0 0])
        set(gca,'FontSize',10,'FontName', 'times new roman');
        title('Correlation Coefficient Curve')
        xlabel('IMF Serial Number')
        ylabel('Correlation coefficient')
        legend('E','N','U','location','best')
        set(gca,'FontSize',8)
        dname = cd;
        dname = [dname '\NoiseReduction\Method1'];
        f = '\\Fig_Method1_CORR.fig';
        saveas(gcf,[dname f])

        figure
        hold on
        plot(time(:,1),RawData(:,1))
        plot(time(:,1),data(:,1),'r')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1,1),time(end,1)])

        legend('RawData','Method1 ','location','best')
        xlabel('Time')
        ylabel('Amplitude/mm')
        title('E---RawData vs Noise Reduction Signals') 
        dname = cd;
        dname = [dname '\NoiseReduction\Method1'];
        f = '\\Fig_Method1_E_Data.fig';
        saveas(gcf,[dname f])

        figure
        hold on
        plot(time(:,2),RawData(:,2))
        plot(time(:,2),data(:,2),'g')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1,2),time(end,2)])
        legend('RawData','Method1 ','location','best')
        xlabel('Time')
        ylabel('Amplitude/mm')
        title('N---RawData vs Noise Reduction Signals') 
        dname = cd;
        dname = [dname '\NoiseReduction\Method1'];
        f = '\Fig_Method1_N_Data.fig';
        saveas(gcf,[dname f])

        figure
        hold on
        plot(time(:,3),RawData(:,3))
        plot(time(:,3),data(:,3),'k')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1,3),time(end,3)])
        set(gca,'FontSize',8)
        legend('RawData','Method1 ','location','best')
        xlabel('Time/s')
        ylabel('Amplitude/mm')
        title('U---RawData vs Noise Reduction Signals') 

        dname = [cd '\NoiseReduction\Method1'];
        f = '\Fig_Method1_U_Data.fig';
        saveas(gcf,[dname f])
    end

end

