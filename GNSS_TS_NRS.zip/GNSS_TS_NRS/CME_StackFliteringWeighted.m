function  namelist = CME_StackFliteringWeighted(filepath)
%% 2.stack filtering Weighted
    current = filepath;
    A=dir(current);
    for ss=3:length(A)
        folder = strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        [Gcd,num,x,y,z,Sx,Sy,Sz,Rxy,Rxz,Ryz,lon,lati] = textread(folder, '%s%f%f%f%f%f%f%f%f%f%f%f%f', 'delimiter','\t');
        fclose(fid);
        xx(:,ss-2)=x;
        yy(:,ss-2)=y;
        zz(:,ss-2)=z;
        SxSx(:,ss-2)=Sx;
        SySy(:,ss-2)=Sy;
        SzSz(:,ss-2)=Sz;
        RxyRxy(:,ss-2)=Rxy;
        RxzRxz(:,ss-2)=Rxz;
        RyzRyz(:,ss-2)=Ryz;
        longlong(:,ss-2)=lon;
        latilati(:,ss-2)=lati;
        GcdGcd(:,ss-2)=Gcd;
        clearvars -except num current current1 new_folder A AA xx yy zz SxSx SySy SzSz RxyRxy RxzRxz RyzRyz x1 y1 z1 GcdGcd site longlong latilati;
    end
        
    for ss = 3:length(A)
        namelist{ss-2} = A(ss,1).name(1:4);
    end

    [m,n]=size(xx);
    CME2x=0;
    CME2y=0;
    CME2z=0;
    Sxx=0;
    Syy=0;
    Szz=0;
% caculate corr
    for i=1:n
        for j=1:n
            rx=corr([xx(:,i),xx(:,j)]);
            rxx(i,j)=rx(1,2);
            ry=corr([yy(:,i),yy(:,j)]);
            ryy(i,j)=ry(1,2);
            rz=corr([zz(:,i),zz(:,j)]);
            rzz(i,j)=rz(1,2);
        end
    end
% Raw data RMS
    for i=1:n
        RMS0x(i,1)=sqrt(sum(xx(:,i).^2)/length(num));
        RMS0y(i,1)=sqrt(sum(yy(:,i).^2)/length(num));
        RMS0z(i,1)=sqrt(sum(zz(:,i).^2)/length(num));
    end
    RMS = [RMS0x RMS0y RMS0z];
    dname = [cd '\CME\'];
    fn = 'RMS.txt';
    save ([dname fn],'RMS','-ascii')

    %%  2.
    for i=1:n
        Sxx=Sxx+1./(SxSx(:,i).^2);
        Syy=Syy+1./(SySy(:,i).^2);
        Szz=Szz+1./(SzSz(:,i).^2);
    end
    for i=1:n
        CME2x=CME2x+xx(:,i)./(SxSx(:,i).^2)./Sxx;
        CME2y=CME2y+yy(:,i)./(SySy(:,i).^2)./Syy;
        CME2z=CME2z+zz(:,i)./(SzSz(:,i).^2)./Szz;
    end
    for i=1:n
        pointname=A(i+2,1).name(1:4);
        lvx2(:,i)=xx(:,i)-CME2x;
        lvy2(:,i)=yy(:,i)-CME2y;
        lvz2(:,i)=zz(:,i)-CME2z;

        figure
        subplot(3,2,1)
        plot(num,xx(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvx2(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('East');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,3)
        plot(num,yy(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvy2(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('North');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,5)
        plot(num,zz(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvz2(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('Up')
        ylabel('Displacement/mm');
        xlabel('Year')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,2)
        plot(num,CME2x,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('East');
        ylabel('Displacement/mm');
        title('CME-East')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,4)
        plot(num,CME2y,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('North');
        ylabel('Displacement/mm');
        title('CME-North')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,6)
        plot(num,CME2z,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('Up');
        ylabel('Displacement/mm');
        xlabel('Year')
        title('CME-Up')
        xlim([num(1) num(end)]);
        hold off


        dname = cd;
        dname = strcat(dname,'\CME\Stack_Flitering_Weighted\graph\');
        f = strcat( pointname ,'.fig' );
        saveas(gcf,[dname f])
%% to.mom
        fid2E=strcat(cd,'\CME\Stack_Flitering_Weighted\.mom\',A(i+2,1).name(1:4),'_0.mom');
        txt2E = fopen(fid2E, 'w');

        fid2N=strcat(cd,'\CME\Stack_Flitering_Weighted\.mom\',A(i+2,1).name(1:4),'_1.mom');
        txt2N = fopen(fid2N, 'w');

        fid2U=strcat(cd,'\CME\Stack_Flitering_Weighted\.mom\',A(i+2,1).name(1:4),'_2.mom');
        txt2U = fopen(fid2U, 'w');

        fprintf(txt2E,'%s\n','# sampling period 1');
        fprintf(txt2N,'%s\n','# sampling period 1');
        fprintf(txt2U,'%s\n','# sampling period 1');

        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt2E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt2E,'%8.6f\t\n',lvx2(j,i));
            else
              fprintf(txt2E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt2E,'%8.6f\t\n',lvx2(j,i));
            end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt2N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt2N,'%8.6f\t\n',lvy2(j,i));
            else
              fprintf(txt2N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt2N,'%8.6f\t\n',lvy2(j,i));
            end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt2U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt2U,'%8.6f\t\n',lvz2(j,i));
            else
              fprintf(txt2U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt2U,'%8.6f\t\n',lvz2(j,i));
            end
        end   
        fid2=strcat(cd,'\CME\Stack_Flitering_Weighted','\',A(i+2,1).name);
        txt2 = fopen(fid2, 'w');
        for j=1:length(num)
            fprintf(txt2,'%8.8f\t',num(j,1));
            fprintf(txt2,'%8.2f\t',lvx2(j,i));
            fprintf(txt2,'%8.2f\t',lvy2(j,i));
            fprintf(txt2,'%8.2f\t',SxSx(j,i));
            fprintf(txt2,'%8.2f\t',SySy(j,i));
            fprintf(txt2,'%8.4f\t',RxyRxy(j,i));
            fprintf(txt2,'%8.2f\t',lvz2(j,i));
            fprintf(txt2,'%8.2f\t',SzSz(j,i));
            fprintf(txt2,'%8.4f\t',RxzRxz(j,i));
            fprintf(txt2,'%8.4f\t',RyzRyz(j,i));
            fprintf(txt2,'%s\t',char(GcdGcd{j,1}));
            fprintf(txt2,'%8.4f\t',longlong(j,i));
            fprintf(txt2,'%8.4f\t\n',latilati(j,i));
        end
        RMS2x(i,1)=sqrt(sum(lvx2(:,i).^2)/length(num));
        RMS2y(i,1)=sqrt(sum(lvy2(:,i).^2)/length(num));
        RMS2z(i,1)=sqrt(sum(lvz2(:,i).^2)/length(num));
    end
    RMS2 = [RMS2x RMS2y RMS2z];
    dname = [cd '\CME\Stack_Flitering_Weighted\'];
    fn = 'RMS2.txt';
    save ([dname fn],'RMS2','-ascii')
    fclose('all');
end