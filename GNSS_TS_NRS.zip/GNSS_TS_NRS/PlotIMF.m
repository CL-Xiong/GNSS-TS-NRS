function PlotIMF(imf,Method)
    GlobalConstant
    if MJD_Time(1) < 50000
        time = MJD_Time;
    end
    if MJD_Time(1) > 50000
        time = MJD2Day(MJD_Time);
    end
    
    figure
    k = 1;number = 1;
    for i = 1:1:length(imf)
        subplot(4,1,number)
        da = imf{i};
        plot(time,da');
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1) time(end)])
        if i ~= length(imf)
            str = strcat('IMF',num2str(i));
            ylabel(str);
        end
        if i == length(imf)
            str = 'residual';
            ylabel(str);
            dname = [cd '\NoiseReduction\Method',num2str(Method),'\' ];
            k = k+1;
            f = [num2str(gcf) '.fig'];
            saveas(gcf,[dname f])
            break
        end
        number = number+1;

        if i/4 >= k
            dname = [cd '\NoiseReduction\Method',num2str(Method),'\' ];
            f = [num2str(gcf) '.fig'];
            saveas(gcf,[dname f])
            figure
            k = k+1;
            number = 1;
        end
    end
end