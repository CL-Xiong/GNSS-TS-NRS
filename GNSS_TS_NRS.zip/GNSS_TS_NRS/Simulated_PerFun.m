function Simulated_PerFun
    GlobalConstant
    prompt = {'Amplitude1','F1','F2','Amplitude2','F3','Amplitude3','F4','DataLength'};
    title = 'Periodic Signal';
    dims = [1 50];
    definput = {'4','800','250','2','600','1','50','1024'};
    options.Resize='on';
    answer = inputdlg(prompt,title,dims,definput,options);
    amplitude1 = str2num(answer{1}); 
    F1 = str2num(answer{2});
    F2 = str2num(answer{3});
    amplitude2 = str2num(answer{4}); 
    F3 = str2num(answer{5}); 
    amplitude3 = str2num(answer{6}); 
    F4 = str2num(answer{7});
    Data_Length = str2num(answer{8}); 
    t=1:1:Data_Length ;
    y1 = amplitude1*sin(2*pi.*t/F1).*sin(2*pi.*t/F2);
    y2 = amplitude2*sin(2*pi.*t/F3);
    y3 = amplitude3*sin(2*pi.*t/F4);
    Simulated_Data = y1 + y2 + y3;
    Simulated_Data = Simulated_Data';
    Simulated_Index = 1;
    Simulated_Choice = 'PerFun';
end