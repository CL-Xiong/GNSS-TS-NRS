function sopac2mom(filepath)
    % *.neu convert to *.mom
    % # YYYYMMDD HHMNSC    DecYr     MJD              N         E         U        dN       +-        dE       +-         dU       +-   
    format long g
    current = filepath;
    A=dir(current); 
    for ss=3:length(A)
        folder=strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        lines = 0;
        str = '# Date DeltaN(m) DeltaE(m) DeltaU(m) SigmaN(m) SigmaE(m) SigmaU(m)';
        while 1 
            a = fgetl(fid);
            if  strcmp(a,str)
                lines = lines+1;
                break
            end
            lines = lines+1;
        end  
        pointname = A(ss,1).name(1:4);
        data = textscan (fid, '%f %f %f %f %f %f %f ');
        YYYYMMDD = data{1};
        DeltaN = data{2};
        N = DeltaN.*1000;
        DeltaE = data{3};
        E = DeltaE.*1000;
        DeltaU = data{4};
        U = DeltaU.*1000;
        SigmaN = data{5};
        SigmaE = data{6};
        SigmaU = data{7};
        MJD = Day2MJD(YYYYMMDD);
        fclose(fid);
        
        dname = [cd '\TSprocessing\Format Tool\'];
        
        fn0 = strcat(dname,pointname,'_0.mom');
        fid0 = fopen(fn0,'w');
        fprintf(fid0,'# sampling period 1\n');
        for i = 1:length(MJD)
            fprintf(fid0,'%f\t',MJD(i));
            fprintf(fid0,'%f\n',E(i));
        end
        fclose(fid0);
        
        
        fn1 = strcat(dname,pointname,'_1.mom');
        fid1 = fopen(fn1,'w');
        fprintf(fid1,'# sampling period 1\n');
        for i = 1:length(MJD)
            fprintf(fid1,'%f\t',MJD(i));
            fprintf(fid1,'%f\n',N(i));
        end
        fclose(fid1);
        
        fn2 = strcat(dname,pointname,'_2.mom');
        fid2 = fopen(fn2,'w');
        fprintf(fid2,'# sampling period 1\n');
        for i = 1:length(MJD)
            fprintf(fid2,'%f\t',MJD(i));
            fprintf(fid2,'%f\n',U(i));
        end
        fclose(fid2);
    end
    msgbox('Finished!')
end
