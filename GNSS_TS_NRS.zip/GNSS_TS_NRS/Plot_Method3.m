function Plot_Method3(RawData,data)
    GlobalConstant
    if  Simulated_Index == 1
        time = MJD_Time;
    else
        time = MJD2Day(MJD_Time);
    end
    %%
    if Choose_Index == 1
        figure
        hold on
        plot(time,RawData)
        plot(time,data,'color',[1 0 0])
        set(gca,'FontSize',10,'FontName', 'times new roman');
        title('RawData vs Noise Reduction Signals')
        xlabel('Time')
        ylabel('Amplitude/mm')
        xlim([time(1),time(end)])
        legend('RawData','Method3 ','location','best')
        dname = cd;
        dname = [dname '\NoiseReduction\Method3'];
        f = '\\Fig_Method3_Data.fig';
        saveas(gcf,[dname f])

    end

    if Choose_Index == 3
        figure
        hold on
        plot(time(:,1),RawData(:,1))
        plot(time(:,1),data(:,1),'r')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1,1),time(end,1)])
        legend('RawData','Method3 ','location','best')
        xlabel('Time')
        ylabel('Amplitude/mm')
        title('E---RawData vs Noise Reduction Signals') 
        dname = cd;
        dname = [dname '\NoiseReduction\Method3'];
        f = '\\Fig_Method3_E_Data.fig';
        saveas(gcf,[dname f])

        figure
        hold on
        plot(time(:,1),RawData(:,2))
        plot(time(:,1),data(:,2),'g')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1,2),time(end,2)])
        legend('RawData','Method3','location','best')
        xlabel('Time')
        ylabel('Amplitude/mm')
        title('N---RawData vs Noise Reduction Signals') 
        dname = [cd '\NoiseReduction\Method3'];
        f = '\\Fig_Method3_N_Data.fig';
        saveas(gcf,[dname f])

        figure
        hold on
        plot(time(:,1),RawData(:,3))
        plot(time(:,1),data(:,3),'k')
        set(gca,'FontSize',10,'FontName', 'times new roman');
        xlim([time(1,3),time(end,3)])
        legend('RawData','Method3 ','location','best')
        xlabel('Time')
        ylabel('Amplitude/mm')
        title('U---RawData vs Noise Reduction Signals') 
        dname = cd;
        dname = [dname '\NoiseReduction\Method3'];
        f = '\\Fig_Method3_U_Data.fig';
        saveas(gcf,[dname f])
    end


end

