function  namelist = CME_CorrelationWeightedStackingFiltering (filepath)
%% 3.Correlation weighted stacking filtering 
    current = filepath;
    A=dir(current);
    for ss=3:length(A)
        folder=strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        pointname=A(ss,1).name(1:4);
        [Gcd,num,x,y,z,Sx,Sy,Sz,Rxy,Rxz,Ryz,lon,lati] = textread(folder, '%s%f%f%f%f%f%f%f%f%f%f%f%f', 'delimiter','\t');
        fclose(fid)
        xx(:,ss-2)=x;
        yy(:,ss-2)=y;
        zz(:,ss-2)=z;
        SxSx(:,ss-2)=Sx;
        SySy(:,ss-2)=Sy;
        SzSz(:,ss-2)=Sz;
        RxyRxy(:,ss-2)=Rxy;
        RxzRxz(:,ss-2)=Rxz;
        RyzRyz(:,ss-2)=Ryz;
        longlong(:,ss-2)=lon;
        latilati(:,ss-2)=lati;
        GcdGcd(:,ss-2)=Gcd;
        clearvars -except num current current1 new_folder A AA xx yy zz SxSx SySy SzSz RxyRxy RxzRxz RyzRyz x1 y1 z1 GcdGcd site longlong latilati;
    end
    for ss = 3:length(A)
        namelist{ss-2} = A(ss,1).name(1:4);
    end
    [m,n]=size(xx);
    CME3xxx=0;
    CME3yyy=0;
    CME3zzz=0;
    Sxx=0;
    Syy=0;
    Szz=0;
    % caculate corr
    for i=1:n
        for j=1:n
            rx=corr([xx(:,i),xx(:,j)]);
            rxx(i,j)=rx(1,2);
            ry=corr([yy(:,i),yy(:,j)]);
            ryy(i,j)=ry(1,2);
            rz=corr([zz(:,i),zz(:,j)]);
            rzz(i,j)=rz(1,2);
        end
    end
% Raw data RMS
    for i=1:n
        RMS0x(i,1)=sqrt(sum(xx(:,i).^2)/length(num));
        RMS0y(i,1)=sqrt(sum(yy(:,i).^2)/length(num));
        RMS0z(i,1)=sqrt(sum(zz(:,i).^2)/length(num));
    end
        RMS = [RMS0x RMS0y RMS0z];
        dname = [cd '\CME\'];
        fn = 'RMS.txt';
        save ([dname fn],'RMS','-ascii')

%%  3.Correlation weighted stacking filtering 
    for i=1:n
        for j=1:n
            weight3x(:,j)=rxx(i,j)./SxSx(:,j).^2;
            weight3y(:,j)=ryy(i,j)./SySy(:,j).^2;
            weight3z(:,j)=rzz(i,j)./SzSz(:,j).^2;
        end
        weight3xx(i,1)={weight3x};
        weight3yy(i,1)={weight3y};
        weight3zz(i,1)={weight3z};
        CME3xx(:,i)=CME3xxx+xx(:,i).*weight3x(:,i);
        CME3yy(:,i)=CME3yyy+yy(:,i).*weight3y(:,i);
        CME3zz(:,i)=CME3zzz+zz(:,i).*weight3z(:,i);
    end
    %cme
    for i=1:n
        CME3x(:,i)=CME3xx(:,i)./sum(weight3xx{i,1},2);
        CME3y(:,i)=CME3yy(:,i)./sum(weight3yy{i,1},2);
        CME3z(:,i)=CME3zz(:,i)./sum(weight3zz{i,1},2);
    end
    
    for i=1:n
        
        lvx3(:,i)=xx(:,i)-CME3x(:,i);
        lvy3(:,i)=yy(:,i)-CME3y(:,i);
        lvz3(:,i)=zz(:,i)-CME3z(:,i);
        RMS3x(i,1)=sqrt(sum(lvx3(:,i).^2)/length(num));
        RMS3y(i,1)=sqrt(sum(lvy3(:,i).^2)/length(num));
        RMS3z(i,1)=sqrt(sum(lvz3(:,i).^2)/length(num));

        %% draw
        figure
        subplot(3,2,1)
        plot(num,xx(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvx3(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('East');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,3)
        plot(num,yy(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvy3(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('North');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,5)
        plot(num,zz(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvz3(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('Up')
        ylabel('Displacement/mm');
        xlabel('Year')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,2)
        plot(num,CME3x(:,i),'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('East');
        ylabel('Displacement/mm');
        title('CME-East')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,4)
        plot(num,CME3y(:,i),'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('North');
        ylabel('Displacement/mm');
        title('CME-North')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,6)
        plot(num,CME3z(:,i),'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('Up');
        ylabel('Displacement/mm');
        xlabel('Year')
        title('CME-Up')
        xlim([num(1) num(end)]);
        hold off

        pointname=A(i+2,1).name(1:4);
        dname = cd;
        dname = [dname '\CME\Correlation_Weighted_Stacking_Filtering\graph\'];
        f = strcat( pointname ,'.fig' );
        saveas(gcf,[dname f])
   %% to.mom 
        fid3E = strcat(cd,'\CME\Correlation_Weighted_Stacking_Filtering\.mom\',A(i+2,1).name(1:4),'_0.mom');
        txt3E = fopen(fid3E, 'w');

        fid3N=strcat(cd,'\CME\Correlation_Weighted_Stacking_Filtering\.mom\',A(i+2,1).name(1:4),'_1.mom');
        txt3N = fopen(fid3N, 'w');

        fid3U = strcat(cd,'\CME\Correlation_Weighted_Stacking_Filtering\.mom\',A(i+2,1).name(1:4),'_2.mom');
        txt3U = fopen(fid3U, 'w');

        fprintf(txt3E,'%s\n','# sampling period 1');
        fprintf(txt3N,'%s\n','# sampling period 1');
        fprintf(txt3U,'%s\n','# sampling period 1');

        for j=1:length(num)
        if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
            fprintf(txt3E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
            fprintf(txt3E,'%8.6f\t\n',lvx3(j,i));
        else
          fprintf(txt3E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
          fprintf(txt3E,'%8.6f\t\n',lvx3(j,i));
        end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt3N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt3N,'%8.6f\t\n',lvy3(j,i));
            else
                fprintf(txt3N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
                fprintf(txt3N,'%8.6f\t\n',lvy3(j,i));
            end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt3U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt3U,'%8.6f\t\n',lvz3(j,i));
            else
              fprintf(txt3U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt3U,'%8.6f\t\n',lvz3(j,i));
            end
        end
   %% save data
        fid3 = strcat(cd,'\CME\Correlation_Weighted_Stacking_Filtering','\',A(i+2,1).name);
        txt3 = fopen(fid3, 'w');
        for j=1:length(num)
            fprintf(txt3,'%8.8f\t',num(j,1));
            fprintf(txt3,'%8.2f\t',lvx3(j,i));
            fprintf(txt3,'%8.2f\t',lvy3(j,i));
            fprintf(txt3,'%8.2f\t',SxSx(j,i));
            fprintf(txt3,'%8.2f\t',SySy(j,i));
            fprintf(txt3,'%8.4f\t',RxyRxy(j,i));
            fprintf(txt3,'%8.2f\t',lvz3(j,i));
            fprintf(txt3,'%8.2f\t',SzSz(j,i));
            fprintf(txt3,'%8.4f\t',RxzRxz(j,i));
            fprintf(txt3,'%8.4f\t',RyzRyz(j,i));
            fprintf(txt3,'%s\t',char(GcdGcd{1,1}));
            fprintf(txt3,'%8.4f\t',longlong(j,i));
            fprintf(txt3,'%8.4f\t\n',latilati(j,i));
        end
        RMS3x(i,1)=sqrt(sum(lvx3(:,i).^2)/length(num));
        RMS3y(i,1)=sqrt(sum(lvy3(:,i).^2)/length(num));
        RMS3z(i,1)=sqrt(sum(lvz3(:,i).^2)/length(num));
    end
    RMS3 = [RMS3x RMS3y RMS3z];
    dname = [cd '\CME\Correlation_Weighted_Stacking_Filtering\'];
    fn = 'RMS3.txt';
    save ([dname fn],'RMS3','-ascii')
    
    
end