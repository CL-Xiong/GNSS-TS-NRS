function namelist = CME_PCA(filepath)
%% 5.PCA
current = filepath;
A = dir(current);
for ss=3:length(A)
    folder=strcat(current,'\',A(ss,1).name);
    fid = fopen(folder);
    [Gcd,num,x,y,z,Sx,Sy,Sz,Rxy,Rxz,Ryz,lon,lati] = textread(folder, '%s%f%f%f%f%f%f%f%f%f%f%f%f', 'delimiter','\t');
    fclose(fid);
    xx(:,ss-2)=x;
    yy(:,ss-2)=y;
    zz(:,ss-2)=z;
    SxSx(:,ss-2)=Sx;
    SySy(:,ss-2)=Sy;
    SzSz(:,ss-2)=Sz;
    RxyRxy(:,ss-2)=Rxy;
    RxzRxz(:,ss-2)=Rxz;
    RyzRyz(:,ss-2)=Ryz;
    longlong(:,ss-2)=lon;
    latilati(:,ss-2)=lati;
    GcdGcd(:,ss-2)=Gcd;
    clearvars -except num current current1 new_folder A AA time xx yy zz SxSx SySy SzSz RxyRxy RxzRxz RyzRyz x1 y1 z1 GcdGcd site longlong latilati;
end
for ss = 3:length(A)
    namelist{ss-2} = A(ss,1).name(1:4);
end
% Raw data RMS
[m,n]=size(xx);
for i=1:n
    RMS0x(i,1)=sqrt(sum(xx(:,i).^2)/length(num));
    RMS0y(i,1)=sqrt(sum(yy(:,i).^2)/length(num));
    RMS0z(i,1)=sqrt(sum(zz(:,i).^2)/length(num));
end
RMS = [RMS0x RMS0y RMS0z];
dname = [cd '\CME\'];
fn = 'RMS.txt';
save ([dname fn],'RMS','-ascii')

%% PCA
[a_E,v_E,d_E] = pcaCME(xx);
[a_N,v_N,d_N] = pcaCME(yy);
[a_U,v_U,d_U] = pcaCME(zz);

sum_de = sum(d_E);
sum_dn = sum(d_N);
sum_du = sum(d_U);

pre_de = d_E/sum_de;
pre_dn = d_N/sum_dn;
pre_du = d_U/sum_du;

% qq=1,PCs
% set the former PCs as CME
prompt = {'PCs: set the former PCs as CME'};
tit = 'PCA';
dims = [1 50];
definput = {'1'};
options.Resize='on';
answer = inputdlg(prompt,tit,dims,definput,options);
Q = str2num(answer{1});

for i=1:length(num)
    for j=1:n
        tempe=0;
        tempn=0;
        tempu=0;
        for q=1:Q
            tempe=tempe+a_E(i,q)*v_E(j,q);
            tempn=tempn+a_N(i,q)*v_N(j,q);
            tempu=tempu+a_U(i,q)*v_U(j,q);
        end
        CME5x(i,j)=tempe;
        CME5y(i,j)=tempn;
        CME5z(i,j)=tempu;% menas the CME
    end
end

for i =1:n
    lvx5(:,i)=xx(:,i)-CME5x(:,i);
    lvy5(:,i)=yy(:,i)-CME5y(:,i);
    lvz5(:,i)=zz(:,i)-CME5z(:,i);
    RMS5x(i,1)=sqrt(sum(lvx5(:,i).^2)/length(num));
    RMS5y(i,1)=sqrt(sum(lvy5(:,i).^2)/length(num));
    RMS5z(i,1)=sqrt(sum(lvz5(:,i).^2)/length(num));
end
%% draw
for i =1:n
    figure
    subplot(3,2,1)
    plot(num,xx(:,i),'-black','linewidth',1)
    set(gca, 'FontName', 'Times New Roman');
    hold on
    plot(num,lvx5(:,i),'-r','linewidth',1)
    legend('Before','After');
    title('East');
    ylabel('Displacement/mm');
    xlim([num(1) num(end)]);
    hold off
    
    subplot(3,2,3)
    plot(num,yy(:,i),'-black','linewidth',1)
    set(gca, 'FontName', 'Times New Roman');
    hold on
    plot(num,lvy5(:,i),'-r','linewidth',1)
    legend('Before','After');
    title('North');
    ylabel('Displacement/mm');
    xlim([num(1) num(end)]);
    hold off
    
    subplot(3,2,5)
    plot(num,zz(:,i),'-black','linewidth',1)
    set(gca, 'FontName', 'Times New Roman');
    hold on
    plot(num,lvz5(:,i),'-r','linewidth',1)
    legend('Before','After');
    title('Up')
    ylabel('Displacement/mm');
    xlabel('Year')
    xlim([num(1) num(end)]);
    hold off
    
    subplot(3,2,2)
    plot(num,CME5x(:,i),'linewidth',1)
    set(gca, 'FontName', 'Times New Roman');
    hold on
    legend('East');
    ylabel('Displacement/mm');
    title('CME-East')
    xlim([num(1) num(end)]);
    hold off
    
    subplot(3,2,4)
    plot(num,CME5y(:,i),'linewidth',1)
    set(gca, 'FontName', 'Times New Roman');
    hold on
    legend('North');
    ylabel('Displacement/mm');
    title('CME-North')
    xlim([num(1) num(end)]);
    hold off
    
    subplot(3,2,6)
    plot(num,CME5z(:,i),'linewidth',1)
    set(gca, 'FontName', 'Times New Roman');
    hold on
    legend('Up');
    ylabel('Displacement/mm');
    xlabel('Year')
    title('CME-Up')
    xlim([num(1) num(end)]);
    hold off
    
    pointname = A(i+2,1).name(1:4);
    dname = [cd '\CME\PCA\graph\'];
    f = strcat( pointname ,'.fig' );
    saveas(gcf,[dname f])
    
    %% to.mom
    fid5E = strcat(cd,'\CME\PCA\.mom\',A(i+2,1).name(1:4),'_0.mom');
    txt5E = fopen(fid5E, 'w');
    
    fid5N=strcat(cd,'\CME\PCA\.mom\',A(i+2,1).name(1:4),'_1.mom');
    txt5N = fopen(fid5N, 'w');
    
    fid5U = strcat(cd,'\CME\PCA\.mom\',A(i+2,1).name(1:4),'_2.mom');
    txt5U = fopen(fid5U, 'w');
    
    fprintf(txt5E,'%s\n','# sampling period 1');
    fprintf(txt5N,'%s\n','# sampling period 1');
    fprintf(txt5U,'%s\n','# sampling period 1');
    
    for j=1:length(num)
        if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
            fprintf(txt5E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
            fprintf(txt5E,'%8.6f\t\n',lvx5(j,i));
        else
            fprintf(txt5E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
            fprintf(txt5E,'%8.6f\t\n',lvx5(j,i));
        end
    end
    for j=1:length(num)
        if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
            fprintf(txt5N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
            fprintf(txt5N,'%8.6f\t\n',lvy5(j,i));
        else
            fprintf(txt5N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
            fprintf(txt5N,'%8.6f\t\n',lvy5(j,i));
        end
    end
    for j=1:length(num)
        if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
            fprintf(txt5U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
            fprintf(txt5U,'%8.6f\t\n',lvz5(j,i));
        else
            fprintf(txt5U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
            fprintf(txt5U,'%8.6f\t\n',lvz5(j,i));
        end
    end
    %% save data
    fid3 = strcat(cd,'\CME\PCA','\',A(i+2,1).name);
    txt3 = fopen(fid3, 'w');
    for j=1:length(num)
        fprintf(txt3,'%8.8f\t',num(j,1));
        fprintf(txt3,'%8.2f\t',lvx5(j,i));
        fprintf(txt3,'%8.2f\t',lvy5(j,i));
        fprintf(txt3,'%8.2f\t',SxSx(j,i));
        fprintf(txt3,'%8.2f\t',SySy(j,i));
        fprintf(txt3,'%8.4f\t',RxyRxy(j,i));
        fprintf(txt3,'%8.2f\t',lvz5(j,i));
        fprintf(txt3,'%8.2f\t',SzSz(j,i));
        fprintf(txt3,'%8.4f\t',RxzRxz(j,i));
        fprintf(txt3,'%8.4f\t',RyzRyz(j,i));
        fprintf(txt3,'%s\t',char(GcdGcd{1,1}));
        fprintf(txt3,'%8.4f\t',longlong(j,i));
        fprintf(txt3,'%8.4f\t\n',latilati(j,i));
    end
    RMS5x(i,1)=sqrt(sum(lvx5(:,i).^2)/length(num));
    RMS5y(i,1)=sqrt(sum(lvy5(:,i).^2)/length(num));
    RMS5z(i,1)=sqrt(sum(lvz5(:,i).^2)/length(num));
end
RMS5 = [RMS5x RMS5y RMS5z];
dname = [cd '\CME\PCA\'];
fn = 'RMS5.txt';
save ([dname fn],'RMS5','-ascii')
end

