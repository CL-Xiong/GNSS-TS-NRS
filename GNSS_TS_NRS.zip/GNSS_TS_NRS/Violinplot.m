function Violinplot(Hold)
%     Hold = 'hold on';
    filepath = uigetdir(strcat(cd,'\example\NoiseReduction'),'Please choose a folder'); 
    current = filepath;
    A = dir(current);
    num = 0;
if strcmp(Hold,'hold on')
    for k = 3:1:length(A)
        folderE = strcat(current,'\',A(k,1).name);
        fid = fopen(folderE);
        data = textscan(fid,'%f%f','HeaderLines',1);
        resi(:,k-2) = data{2};
        fclose(fid) ; 
        num = num+1;
%         pointname = A(k,1).name;
%         pointname(end-4:end) = [];
%         siteName{num} = A(k,1).name(1:4);
    %% PLOT
    end
        figure
        set(gca,'FontSize',10,'FontName', 'times new roman');
        T = violin(resi);
        ylabel('Displacement/mm')
%         set(gca,'XTickLabel',siteName)
        graph = strcat(cd,'\TSexpression\Violin Plot\all');
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
end

if strcmp(Hold,'hold off')
    for k = 3:1:length(A)
        folderE = strcat(current,'\',A(k,1).name);
        fid = fopen(folderE);
        data = textscan(fid,'%f%f','HeaderLines',1);
        resi = data{2};
        fclose(fid) ;
    %% PLOT
        figure
        set(gca,'FontSize',10,'FontName', 'times new roman');
        T = violin(resi);

        pointname = A(k,1).name;
        graph = strcat(cd,'\TSexpression\Violin Plot\',pointname);
        graph(end-3:end) = [];
        graph = strcat(graph,'.fig');
        saveas(gcf,graph)
    end
end

end