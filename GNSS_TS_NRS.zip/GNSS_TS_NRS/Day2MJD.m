function MJD = Day2MJD(Day)
        MJD = (Day-2000).*365.25+51544;
end