function [data Pk leng] = Method1(RawData)
%   traditioal EMD method
%   return reduced noise data and coefficient of association
%   save  RawData and data , Pk(it is coefficient of association of each IMF )
%   a folder named Method1 which is created in GUImain,
%   in current direction to save data
    GlobalConstant
    if Choose_Index == 1
       allmode = eemd( RawData,0,1);
       [coll row] = size(allmode);
       for mmm = 1:row-1
           imf{mmm} = allmode(:,mmm+1)';
       end
       PlotIMF(imf,1)
       leng = length(imf);
       for i = 1:length(imf)
           Pk(i) = relative(imf{i},RawData);
       end
       lowpeak = findpeaks(-Pk);
       k = lowpeak(1);
       data = zeros(size(RawData));
       for i = k+1:length(imf)
           data = data+imf{i}';
       end
    end
    %%
    if Choose_Index == 3
        data = zeros(size(RawData));
        for col = 1:3
           allmode = eemd( RawData(:,col),0,1);
           [coll row] = size(allmode);
           for mmm = 1:row-1
               imf{mmm} = allmode(:,mmm+1)';
           end
           PlotIMF(imf,1)
           leng = length(imf);
           for i = 1:length(imf)
               Pk(col,i) = relative( imf{i},RawData(:,col) );
           end
           lowpeak = findpeaks(-Pk(col,:));
           k(col) = lowpeak(1);
           for i = k(col)+1:length(imf)
               data(:,col) = data(:,col)+imf{i}';
           end
        end
    end
   %% save data
   % k
   % RawData and data 
   % Pk
for i = 1:Choose_Index
    file  = [MJD_Time(:,i) data(:,i)];
    dname = cd;
    dname = [dname '\NoiseReduction\Method1'];
    if Simulated_Index == 1
        newfn{i} = 'Simulated.mom';
    end 
    fn = newfn{i};
    fid = fopen([dname '\' fn],'w+');
    fprintf(fid,'# sampling period 1.0\n');
    for j = 1:length(MJD_Time)
         fprintf(fid,'%f\t',MJD_Time(j,i));
         fprintf(fid,'%f\n',data(j,i));
    end
    fclose(fid);
end
    dname = [cd '\NoiseReduction\Method1'];
    fn = '\k.txt';
    save ([dname fn],'k','-ascii')

    dname = cd;
    dname = [dname '\NoiseReduction\Method1'];
    fn = '\Pk.txt';
    save ([dname fn],'Pk','-ascii')
end
   
   
   
