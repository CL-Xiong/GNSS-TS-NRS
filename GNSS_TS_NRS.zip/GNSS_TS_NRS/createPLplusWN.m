function noisy=createPLplusWN(t,Amplitude_pl,Amplitude_w,Spectrum_index)
%   create a coloured noise inclouding WN and PL
%   t is number of observations
%   N is number of observations
%   alpha spectural index
    N = t;
    alpha    = Spectrum_index;
    sigma_pl = Amplitude_pl;
    sigma_w  = Amplitude_w;
    noisy = zeros(N,1);
    h = zeros(N,1);
    h(1) = 1;
    for i=2:N
    tau = i-1;
    h(i) = (alpha/2+tau-1)*h(i-1)/tau;
    end
    w1 = sigma_pl*randn(N,1);
    w2 = sigma_w*randn(N,1);
    tem=fftconv(h,w1,1);
    noisy  = tem(1:N) + w2;
end

