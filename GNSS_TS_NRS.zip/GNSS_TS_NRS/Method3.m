function data = Method3(RawData)
%   method3 
%   based on EMD ,average period ,and energy density
%   a folder named Method3 which is created in GUImain,
%   in current direction to save data
GlobalConstant
data = zeros( size(RawData));

for j=1:Choose_Index
    allmode = eemd( RawData(:,j),0,1);
    [coll row] = size(allmode);
    for mmm = 1:row-1
        imf{mmm} = allmode(:,mmm+1)';
    end
    
    
    for i=1:length(imf)
        Parameter(j).nem(i)= length( findpeaks( imf{i}') ) +length( findpeaks( -imf{i}'));             
        Parameter(j).Tk(i)= length(RawData)*2/ Parameter(j).nem(i);
        Parameter(j).Ek(i)=sum( imf{i}.^2 )/ length(RawData) ;
        Parameter(j).ETk(i)=Parameter(j).Ek(i)*Parameter(j).Tk(i);
    end
    for i = 1 : length(imf)-1
        Parameter(j).Rk_1(i) = abs(   Parameter(j).ETk(i+1) / (  1/i *  sum(  Parameter(j).ETk(1:i ) )  )   );
    end
    if length(imf) <= 2 
%         msgbox('The number of IMF is 2 or smaller!')
        break
    end
    Locate = find( Parameter(j).Rk_1 > 2 );

    k = Locate(1);
    for i = k+1:length(imf)
        data(:,j) = data(:,j) + ( imf{i} )';
    end
end

    dname = cd;
    dname = [dname '\NoiseReduction\Method3'];
    fn = '\\k.txt';
    save ([dname fn],'k','-ascii')
    fn = '\\Parameter.mat';
    save ([dname fn],'Parameter')

    for i = 1:Choose_Index
        dname = [cd '\NoiseReduction\Method3'];
        if Simulated_Index == 1
            newfn{i} = 'Simulated.mom';
        end
        fn = newfn{i};
        fid = fopen([dname '\' fn],'w+');
        fprintf(fid,'# sampling period 1.0\n');
        for j = 1:length(MJD_Time)
             fprintf(fid,'%f\t',MJD_Time(j,i));
             fprintf(fid,'%f\n',data(j,i));
        end
        fclose(fid);
    end

end