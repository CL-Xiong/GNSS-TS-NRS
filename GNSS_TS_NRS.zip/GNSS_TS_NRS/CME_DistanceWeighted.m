function  namelist = CME_DistanceWeighted(filepath,filepath1)
% distance weighted
    current = filepath;
    A=dir(current);
    current1 = filepath1;
    A1 = dir(current1);
    for ss=3:length(A)
        folder=strcat(current,'\',A(ss,1).name);
        fid = fopen(folder);
        folder1=strcat(current1,'\',A1(ss,1).name);
        fid1 = fopen(folder1);
        
        [Gcd,num,x,y,z,Sx,Sy,Sz,Rxy,Rxz,Ryz,lon,lati] = textread(folder, '%s%f%f%f%f%f%f%f%f%f%f%f%f', 'delimiter','\t');
        [site,num1,x1,y1,z1,Sx1,Sy1,Sz1,Rxy1,Rxz1,Ryz1,Gcd1] = textread(folder1, '%s%f%f%f%f%f%f%f%f%f%f%s', 'delimiter','\t');

        xx(:,ss-2)=x;
        yy(:,ss-2)=y;
        zz(:,ss-2)=z;
        SxSx(:,ss-2)=Sx;
        SySy(:,ss-2)=Sy;
        SzSz(:,ss-2)=Sz;
        RxyRxy(:,ss-2)=Rxy;
        RxzRxz(:,ss-2)=Rxz;
        RyzRyz(:,ss-2)=Ryz;
        longlong(:,ss-2)=lon;
        latilati(:,ss-2)=lati;
        GcdGcd(:,ss-2)=Gcd;
        xx1(1,ss-2)=x1(1,1);
        yy1(1,ss-2)=y1(1,1);
        zz1(1,ss-2)=z1(1,1);
%         clearvars -except num current current1 new_folder A AA xx yy zz SxSx SySy SzSz RxyRxy RxzRxz RyzRyz x1 y1 z1 GcdGcd site longlong latilati;
        fclose(fid);
        fclose(fid1);
    end

    for ss = 3:length(A)
        namelist{ss-2} = A(ss,1).name(1:4);
    end
    
    [m,n]=size(xx);
    CME4x=0;
    CME4y=0;
    CME4z=0;
    % caculate corr
%     for i=1:n
%         for j=1:n
%             rx=corr([xx(:,i),xx(:,j)]);
%             rxx(i,j)=rx(1,2);
%             ry=corr([yy(:,i),yy(:,j)]);
%             ryy(i,j)=ry(1,2);
%             rz=corr([zz(:,i),zz(:,j)]);
%             rzz(i,j)=rz(1,2);
%         end
%     end
% the RMS of Raw data 
    for i=1:n
        RMS0x(i,1)=sqrt(sum(xx(:,i).^2)/length(num));
        RMS0y(i,1)=sqrt(sum(yy(:,i).^2)/length(num));
        RMS0z(i,1)=sqrt(sum(zz(:,i).^2)/length(num));
    end
        RMS = [RMS0x RMS0y RMS0z];
        dname = [cd '\CME\'];
        fn = 'RMS.txt';
        save ([dname fn],'RMS','-ascii')


%% 4.distance weighted
    Distance=0;
    Cx=0;
    Cy=0;
    Cz=0;
    for i=1:n
        Cx=Cx+xx1(1,i)/n;
        Cy=Cy+yy1(1,i)/n;
        Cz=Cz+zz1(1,i)/n;
    end

    for i=1:n
        Distance=Distance+1./((Cx-xx1(1,i))^2+(Cy-yy1(1,i))^2+(Cz-zz1(1,i))^2);
    end
    for i=1:n
        CME4x=CME4x+xx(:,i)./((Cx-xx1(1,i))^2+(Cy-yy1(1,i))^2+(Cz-zz1(1,i))^2)./Distance;
        CME4y=CME4y+yy(:,i)./((Cx-xx1(1,i))^2+(Cy-yy1(1,i))^2+(Cz-zz1(1,i))^2)./Distance;
        CME4z=CME4z+zz(:,i)./((Cx-xx1(1,i))^2+(Cy-yy1(1,i))^2+(Cz-zz1(1,i))^2)./Distance;
    end

    for i=1:n
        pointname=A(i+2,1).name(1:4);
        lvx4(:,i)=xx(:,i)-CME4x;
        lvy4(:,i)=yy(:,i)-CME4y;
        lvz4(:,i)=zz(:,i)-CME4z;

%% draw 
        figure
        subplot(3,2,1)
        plot(num,xx(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvx4(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('East');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,3)
        plot(num,yy(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvy4(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('North');
        ylabel('Displacement/mm');
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,5)
        plot(num,zz(:,i),'-black','linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        plot(num,lvz4(:,i),'-r','linewidth',1)
        legend('Before','After');
        title('Up')
        ylabel('Displacement/mm');
        xlabel('Year')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,2)
        plot(num,CME4x,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('East');
        ylabel('Displacement/mm');
        title('CME-East')
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,4)
        plot(num,CME4y,'linewidth',1)
        hold on
        legend('North');
        ylabel('Displacement/mm');
        title('CME-North')
        set(gca, 'FontName', 'Times New Roman'); 
        xlim([num(1) num(end)]);
        hold off

        subplot(3,2,6)
        plot(num,CME4z,'linewidth',1)
        set(gca, 'FontName', 'Times New Roman'); 
        hold on
        legend('Up');
        ylabel('Displacement/mm');
        xlabel('Year')
        title('CME-Up')
        xlim([num(1) num(end)]);
        hold off

        dname = cd;
        dname = [dname '\CME\Distance_Weighted\graph\'];
        f = strcat( pointname ,'.fig' );
        saveas(gcf,[dname f])
 %% to.mom
        fid4E=strcat(cd,'\CME\Distance_Weighted\.mom\',A(i+2,1).name(1:4),'_0.mom');
        txt4E = fopen(fid4E, 'w');

        fid4N=strcat(cd,'\CME\Distance_Weighted\.mom\',A(i+2,1).name(1:4),'_1.mom');
        txt4N = fopen(fid4N, 'w');

        fid4U=strcat(cd,'\CME\Distance_Weighted\.mom\',A(i+2,1).name(1:4),'_2.mom');
        txt4U = fopen(fid4U, 'w');

        fprintf(txt4E,'%s\n','# sampling period 1');
        fprintf(txt4N,'%s\n','# sampling period 1');
        fprintf(txt4U,'%s\n','# sampling period 1');

        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt4E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt4E,'%8.6f\t\n',lvx4(j,i));
            else
              fprintf(txt4E,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt4E,'%8.6f\t\n',lvx4(j,i));
            end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt4N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt4N,'%8.6f\t\n',lvy4(j,i));
            else
              fprintf(txt4N,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt4N,'%8.6f\t\n',lvy4(j,i));
            end
        end
        for j=1:length(num)
            if ceil((num(j,1)-0.00136612-2000)*365.25+51544)-ceil((num(1,1)-0.00136612-2000)*365.25+51544)~=j-1
                fprintf(txt4U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544)-1);
                fprintf(txt4U,'%8.6f\t\n',lvz4(j,i));
            else
              fprintf(txt4U,'%8.6f\t',ceil((num(j,1)-0.00136612-2000)*365.25+51544));
              fprintf(txt4U,'%8.6f\t\n',lvz4(j,i));
            end
        end
 %% save data       
        fid4=strcat(cd,'\CME\Distance_Weighted','\',A(i+2,1).name);
        txt4 = fopen(fid4, 'w');
        for j=1:length(num)
            fprintf(txt4,'%8.8f\t',num(j,1));
            fprintf(txt4,'%8.2f\t',lvx4(j,i));
            fprintf(txt4,'%8.2f\t',lvy4(j,i));
            fprintf(txt4,'%8.2f\t',SxSx(j,i));
            fprintf(txt4,'%8.2f\t',SySy(j,i));
            fprintf(txt4,'%8.4f\t',RxyRxy(j,i));
            fprintf(txt4,'%8.2f\t',lvz4(j,i));
            fprintf(txt4,'%8.2f\t',SzSz(j,i));
            fprintf(txt4,'%8.4f\t',RxzRxz(j,i));
            fprintf(txt4,'%8.4f\t',RyzRyz(j,i));
            fprintf(txt4,'%s\t',char(GcdGcd{1,1}));
            fprintf(txt4,'%8.4f\t',longlong(j,i));
            fprintf(txt4,'%8.4f\t\n',latilati(j,i));
        end
        RMS4x(i,1)=sqrt(sum(lvx4(:,i).^2)/length(num));
        RMS4y(i,1)=sqrt(sum(lvy4(:,i).^2)/length(num));
        RMS4z(i,1)=sqrt(sum(lvz4(:,i).^2)/length(num));
    end
    RMS4 = [RMS4x RMS4y RMS4z];
    dname = [cd '\CME\Distance_Weighted\'];
    fn = 'RMS4.txt';
    save ([dname fn],'RMS4','-ascii')
    fclose('all');
    
    
end