function Plot_All(data,index)
    GlobalConstant
    if  Simulated_Index == 1
        time = MJD_Time;
    else
        time = MJD2Day(MJD_Time);
    end
    %%
    if Choose_Index == 1
        str = 'RawData';
        figure
        hold on
        plot(time,RawData);
        set(gca,'FontSize',10,'FontName', 'times new roman');
        title('RawData vs Noise Reduction Signals')
        xlabel('Time')
        ylabel('Amplitude/mm')
        xlim([time(1),time(end)])
        hold on
        for i=1:length(index)
            switch index(i)
                case 1
                    plot(time,data(:,i),'color',[1 0 0]);
                    str = [str;'Method1'];
                case 2
                    plot(time,data(:,i),'color',[0 0 0]);
                    str = [str;'Method2'];
                case 3
                    plot(time,data(:,i),'color',[1 0 1]);
                    str = [str;'Method3'];
                case 4
                    plot(time,data(:,i),'color',[0 1 1]);
                    str = [str;'Method4'];
                case 5
                    plot(time,data(:,i),'g');
                    str = [str;'Method5'];
            end
            legend(str);  
            xlim([time(1,1),time(end,1)])
        end
        dname = cd;
        f = '\NoiseReduction\Fig_All.fig';
        saveas(gcf,[dname f])
    end
    %%
    if Choose_Index == 3
        for n = 1:Choose_Index
            str = 'RawData';
            figure
            hold on
            plot(time(:,n),RawData(:,n));
            set(gca,'FontSize',10,'FontName', 'times new roman');
            if n == 1
                title('E----RawData vs Noise Reduction Signals')
            end
            if n == 2
                title('N----RawData vs Noise Reduction Signals')
            end
            if n == 3
                title('U----RawData vs Noise Reduction Signals')
            end
            xlabel('Time')
            ylabel('Amplitude/mm')
            xlim([time(n,1),time(end,n)])
            hold on
 
            for i = 1:length(index)
                switch index(i)
                    case 1
                        plot(time(:,n),data(:,3*i+n-3),'color',[1 0 0]);
                        str = [str;'Method1'];
                    case 2
                        plot(time(:,n),data(:,3*i+n-3),'color',[0 0 0]);
                        str = [str;'Method2'];
                    case 3
                        plot(time(:,n),data(:,3*i+n-3),'color',[1 0 1]);
                        str = [str;'Method3'];
                    case 4
                        plot(time(:,n),data(:,3*i+n-3),'color',[0 1 1]);
                        str = [str;'Method4'];
                    case 5
                        plot(time(:,n),data(:,3*i+n-3),'color',[1 1 0]);
                        str = [str;'Method5'];
                        hold on
                end
            end
            legend(str);  
            if n == 1
                f = strcat('\NoiseReduction\Fig_All_E.fig');
            end
            if n == 2
                f = strcat('\NoiseReduction\Fig_All_N.fig');
            end
            if n == 3
                f = strcat('\NoiseReduction\Fig_All_U.fig');
            end
            saveas(gcf,[cd f])
        end
    end
    
    
end